package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.zds.mapper.MovieDao;
import cn.zds.pojo.Movie;
import cn.zds.pojo.PageInfo;



/**
 * ��ʳ��Ƶ
 */
@WebServlet("/MovieServlet")
public class MovieServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		  PageInfo pageInfo=new PageInfo();
			pageInfo.setPageSize(9);
			if(request.getParameter("pageNumber")!=null&&!request.getParameter("pageNumber").equals("")){
				pageInfo.setPageNumber(Integer.parseInt(request.getParameter("pageNumber")));
			}
			else {
				pageInfo.setPageNumber(1);
			}
			long count=MovieDao.getallmovies();
			pageInfo.setTotal(count%pageInfo.getPageSize()==0?count/pageInfo.getPageSize():count/pageInfo.getPageSize()+1);
			System.out.println("pageInfo:"+pageInfo);
			int pageStart=pageInfo.getPageSize()*(pageInfo.getPageNumber()-1);
			int pageSize=pageInfo.getPageSize();
			
		ArrayList<Movie> movies = MovieDao.getallmoviesLimit(pageStart, pageSize);
		request.setAttribute("movies", movies);
	    request.setAttribute("pageInfo", pageInfo);
		request.getRequestDispatcher("/movie.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String key = request.getParameter("key");
		String area = request.getParameter("area");
		System.out.println(key);
		System.out.println(area);

		if(area!=null&&!"".equals(area)&&key==null)
		{//查全部
			if(area.equals("全部")){
			doGet(request,response);
			return;
		}
			ArrayList<Movie> movies = MovieDao.selectbyarea(area);
			
			request.setAttribute("movies", movies);
			request.setAttribute("area", area);
		}
		if(key!=null&&!"".equals(key)&&area==null) {
			ArrayList<Movie> movies = MovieDao.selectbyname(key);
			request.setAttribute("movies", movies);
			
		}
		

		request.getRequestDispatcher("/movie.jsp").forward(request, response);
		
		
		
	}

}
