package cn.zds.pojo;

public class Culture {
private int id;
private String cname;
private String city;
//历史起源
private String culture;
//描述
private String describe;
//描述的内容
private String content;
//封面图
private String cover;
//内容图1
private String dp1;
//内容图2
private String dp2;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getCulture() {
	return culture;
}
public void setCulture(String culture) {
	this.culture = culture;
}
public String getDescribe() {
	return describe;
}
public void setDescribe(String describe) {
	this.describe = describe;
}
public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public String getCover() {
	return cover;
}
public void setCover(String cover) {
	this.cover = cover;
}
public String getDp1() {
	return dp1;
}
public void setDp1(String dp1) {
	this.dp1 = dp1;
}
public String getDp2() {
	return dp2;
}
public void setDp2(String dp2) {
	this.dp2 = dp2;
}
@Override
public String toString() {
	return "Culture [id=" + id + ", cname=" + cname + ", city=" + city + ", culture=" + culture + ", describe="
			+ describe + ", content=" + content + ", cover=" + cover + ", dp1=" + dp1 + ", dp2=" + dp2 + "]";
}



}
