package cn.zds.pojo;

public class Foods {
	private int id;
	private String cname;
	private String city;
	private String clc;
	private String dp1;
	private String dp2;
	private String dp3;
	private String culture;
	private String address;
	private int movieId;

	@Override
	public String toString() {
		return "Foods [id=" + id + ", cname=" + cname + ", city=" + city + ", clc=" + clc + ", dp1=" + dp1 + ", dp2="
				+ dp2 + ", dp3=" + dp3 + ", culture=" + culture + ", address=" + address + ", movieId=" + movieId + "]";
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getClc() {
		return clc;
	}
	public void setClc(String clc) {
		this.clc = clc;
	}
	public String getDp1() {
		return dp1;
	}
	public void setDp1(String dp1) {
		this.dp1 = dp1;
	}
	public String getDp2() {
		return dp2;
	}
	public void setDp2(String dp2) {
		this.dp2 = dp2;
	}
	public String getDp3() {
		return dp3;
	}
	public void setDp3(String dp3) {
		this.dp3 = dp3;
	}
	public String getCulture() {
		return culture;
	}
	public void setCulture(String culture) {
		this.culture = culture;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
