package cn.zds.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import cn.zds.pojo.Culture;
import cn.zds.pojo.Foods;




public interface CultureMapper {
	//分页获取所有文化
	@Select("select * from culture limit #{0},#{1}")
	List<Culture> selAllCulture(int pageStart,int pageSize);
	
	//按照城市获取文化
	@Select("select * from culture where city=#{0}")
	List<Culture> selCultureByCity(String city);
	
	//获取所有城市
	@Select("select distinct city from culture")
	List<String> selAllCity();
	
	//根据id获取culture
	@Select("select * from culture where id=#{0}")
	Culture selCultureById(int id);
	
	//根据城市或者名字模糊查询
	@Select("select * from culture where city like #{0} or cname like #{0}")
	List<Culture> selCultureBySerach(String serach);
	
	//获取文化的总数量
	@Select("select count(*) from culture")
	int selAllCultureCount();
	
	//获取前9条、
	@Select("select * from culture limit 1,9")
	 List<Culture> sel1to9();
		 

}
