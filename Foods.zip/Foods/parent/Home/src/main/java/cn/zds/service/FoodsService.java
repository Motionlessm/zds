package cn.zds.service;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import cn.zds.pojo.Foods;;


public interface FoodsService {
	//获取所有食物
	
	List<Foods> selAllFoods(int pageStart,int pageSize);
	
	//按照城市获取食物
	
	List<Foods> selFoodsByCity(String city);
	
	//获取所有城市
	
	List<String> selAllCity();
	
	//根据id获取食物内容
	
	Foods selFoodById(String uid);
	
	//根据城市或者名字模糊查询
	
	List<Foods> selFoodsBySerach(String serach);
	
	//获取食物的总数量
		
	int selAllFoodsCount();
	
}
