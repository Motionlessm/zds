package cn.zds.mapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import cn.zds.pojo.Movie;
import db.DBManager;

public class MovieDao {
	
	//��ȡȫ����Ƶ
	public static ArrayList<Movie> getallmoviesLimit(int pageStart,int pageSize){

		Connection connection = DBManager.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		StringBuilder sqlStateent = new StringBuilder();
		sqlStateent.append("select * from movie limit ?,?");
		
		
		try {
			preparedStatement = connection.prepareStatement(sqlStateent.toString());
			preparedStatement.setInt(1, pageStart);
			preparedStatement.setInt(2, pageSize);
			resultSet = preparedStatement.executeQuery();
			ArrayList<Movie> movies = new ArrayList<>();
			while(resultSet.next()){
				Movie movie = new Movie();
				movie.setId(resultSet.getInt("id"));
				movie.setSrc(resultSet.getString("src"));
				movie.setTitle(resultSet.getString("title"));
				movie.setIntroduce(resultSet.getString("introduce"));
				movie.setImg(resultSet.getString("img"));
				movies.add(movie);
				
			}

			return movies;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
            DBManager.closeAll(connection, preparedStatement, resultSet);
        }	
	}
	
	public static int getallmovies(){
		int count=0;
		Connection connection = DBManager.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		StringBuilder sqlStateent = new StringBuilder();
		sqlStateent.append("select count(*) from movie");
		
		
		try {
			preparedStatement = connection.prepareStatement(sqlStateent.toString());
			
			resultSet = preparedStatement.executeQuery();
		
			while(resultSet.next()){
				count=resultSet.getInt(1);
				
			}

			
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		}finally {
            DBManager.closeAll(connection, preparedStatement, resultSet);
        }
		return count;	
	}
	
	//����id��ȡ��Ƶ
	public static Movie getbyid(int id){

		Connection connection = DBManager.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		StringBuilder sqlStateent = new StringBuilder();
		sqlStateent.append("select * from movie where id = ?");
		
		
		try {
			preparedStatement = connection.prepareStatement(sqlStateent.toString());
			preparedStatement.setInt(1, id);
			resultSet = preparedStatement.executeQuery();
			Movie movie = new Movie();
			if(resultSet.next()){
				
				movie.setId(resultSet.getInt("id"));
				movie.setSrc(resultSet.getString("src"));
				movie.setTitle(resultSet.getString("title"));
				movie.setIntroduce(resultSet.getString("introduce"));
				movie.setImg(resultSet.getString("img"));
			
				
			}

			return movie;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
            DBManager.closeAll(connection, preparedStatement, resultSet);
        }	
	}
	
	//������ѯ
	public static ArrayList<Movie> selectbyarea(String area){

		Connection connection = DBManager.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		StringBuilder sqlStateent = new StringBuilder();
		sqlStateent.append("select * from movie where area = ?");
		
		
		try {
			ArrayList<Movie> movies = new ArrayList<>();
			if(area.equals("全部")) {
				movies = getallmoviesLimit(1, 9);
			}else {
				preparedStatement = connection.prepareStatement(sqlStateent.toString());
				preparedStatement.setString(1, area);
				resultSet = preparedStatement.executeQuery();
				
				while(resultSet.next()){
					Movie movie = new Movie();
					movie.setId(resultSet.getInt("id"));
					movie.setSrc(resultSet.getString("src"));
					movie.setTitle(resultSet.getString("title"));
					movie.setIntroduce(resultSet.getString("introduce"));
					movie.setImg(resultSet.getString("img"));
					movies.add(movie);
					
				}
			}

			return movies;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
            DBManager.closeAll(connection, preparedStatement, resultSet);
        }	
	}
	
	//����title��ѯ
	public static ArrayList<Movie> selectbyname(String key){

		Connection connection = DBManager.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		StringBuilder sqlStateent = new StringBuilder();
		sqlStateent.append("select * from movie where title like ?");
		
		
		try {
			preparedStatement = connection.prepareStatement(sqlStateent.toString());
			preparedStatement.setString(1, "%"+key+"%");
			resultSet = preparedStatement.executeQuery();
			ArrayList<Movie> movies = new ArrayList<>();
			while(resultSet.next()){
				Movie movie = new Movie();
				movie.setId(resultSet.getInt("id"));
				movie.setSrc(resultSet.getString("src"));
				movie.setTitle(resultSet.getString("title"));
				movie.setIntroduce(resultSet.getString("introduce"));
				movie.setImg(resultSet.getString("img"));
				movies.add(movie);
				
			}
			System.out.println(movies);
			return movies;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
            DBManager.closeAll(connection, preparedStatement, resultSet);
        }	
	}
	
	public static ArrayList<Movie> selectbykeyandarea(String key,String area){

		Connection connection = DBManager.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		StringBuilder sqlStateent = new StringBuilder();
		sqlStateent.append("select * from movie where title like ? and area = ?");
		
		
		try {
			ArrayList<Movie> movies = new ArrayList<>();
			if(area.equals("ȫ��")) {
				movies = selectbyname(key);
			}else {
				preparedStatement = connection.prepareStatement(sqlStateent.toString());
				preparedStatement.setString(1, "%"+key+"%");
				resultSet = preparedStatement.executeQuery();
				
				while(resultSet.next()){
					Movie movie = new Movie();
					movie.setId(resultSet.getInt("id"));
					movie.setSrc(resultSet.getString("src"));
					movie.setTitle(resultSet.getString("title"));
					movie.setIntroduce(resultSet.getString("introduce"));
					movie.setImg(resultSet.getString("img"));
					movies.add(movie);
					
				}
				
			}
		
			return movies;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
            DBManager.closeAll(connection, preparedStatement, resultSet);
        }	

	}
}
