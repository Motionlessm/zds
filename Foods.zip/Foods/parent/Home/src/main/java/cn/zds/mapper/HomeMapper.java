package cn.zds.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import cn.zds.pojo.Foods;




public interface HomeMapper {
	
	@Select("select * from my_home limit 1,9")
	List<Foods> sel1to9();
}
