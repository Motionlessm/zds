package cn.zds.service.impl;

import java.rmi.server.UID;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zds.mapper.HomeMapper;
import cn.zds.pojo.Foods;
import cn.zds.service.HomeService;


@Service
public class HomeServiceImpl implements HomeService {
	@Resource
	private HomeMapper homeMapper;

	@Override
	public List<Foods> sel1to9() {
		// TODO Auto-generated method stub
		return homeMapper.sel1to9();
	}
	

	

}
