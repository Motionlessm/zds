package cn.zds.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.zds.pojo.Culture;
import cn.zds.pojo.Foods;
import cn.zds.service.CultureService;
import cn.zds.service.FoodsService;
import cn.zds.service.HomeService;
@Controller
public class HomeController {
@Resource 
private HomeService homeServiceImpl;
@Resource 
private FoodsService foodsServiceimpl;
@Resource 
private CultureService cultureServiceimpl;
@RequestMapping("/main")
public String main(HttpServletRequest req,HttpServletResponse resp){
	try {
		req.setCharacterEncoding("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    resp.setContentType("text/html; charset=UTF-8");
    List<Foods> foods=homeServiceImpl.sel1to9();
    HttpSession session = req.getSession();
    session.setAttribute("foods", foods);
    List<String> citys=foodsServiceimpl.selAllCity();
    req.getSession().setAttribute("citys", citys);
    List<Culture> cultures=cultureServiceimpl.sel1to9();
    List<String> cutureCitys=cultureServiceimpl.selAllCity();
    session.setAttribute("cultures", cultures);
    session.setAttribute("cutureCitys", cutureCitys);
    System.out.println("citys:"+citys);
    System.out.println("cultures:"+cultures);
	System.out.println(foods);
	return "/index.jsp";
	
}
}
