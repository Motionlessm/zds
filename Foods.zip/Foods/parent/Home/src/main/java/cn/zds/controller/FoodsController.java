package cn.zds.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.zds.pojo.Foods;
import cn.zds.pojo.PageInfo;
import cn.zds.service.FoodsService;
import cn.zds.service.HomeService;
@Controller
public class FoodsController {
@Resource 
private FoodsService foodsServiceimpl;
@RequestMapping("/getAllFoods")
public String main(HttpServletRequest req,HttpServletResponse resp){
	try {
		req.setCharacterEncoding("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    resp.setContentType("text/html; charset=UTF-8");
    
    PageInfo pageInfo=new PageInfo();
	pageInfo.setPageSize(9);
	if(req.getParameter("pageNumber")!=null&&!req.getParameter("pageNumber").equals("")){
		pageInfo.setPageNumber(Integer.parseInt(req.getParameter("pageNumber")));
	}
	else {
		pageInfo.setPageNumber(1);
	}
	long count=foodsServiceimpl.selAllFoodsCount();
	pageInfo.setTotal(count%pageInfo.getPageSize()==0?count/pageInfo.getPageSize():count/pageInfo.getPageSize()+1);
	System.out.println("pageInfo:"+pageInfo);
	int pageStart=pageInfo.getPageSize()*(pageInfo.getPageNumber()-1);
	int pageSize=pageInfo.getPageSize();
	
	
    //获取全部食物 
    List<Foods> foods=foodsServiceimpl.selAllFoods(pageStart, pageSize);
    req.setAttribute("foods", foods);
    req.setAttribute("pageInfo", pageInfo);
    System.out.println("foods:"+foods);
    //获取全部城市

    
    
    
	return "/foods_city.jsp";
	
}

@RequestMapping("/getCdFood")
public String getCdFood(HttpServletRequest req,HttpServletResponse resp){
	try {
		req.setCharacterEncoding("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    resp.setContentType("text/html; charset=UTF-8");
    //根据id准确获取食物
   
   String id=req.getParameter("id");
   Foods food=foodsServiceimpl.selFoodById(id);
    req.setAttribute("food", food);
    System.out.println("food:"+food);
    
	return "/cd_food.jsp";
	
}

@RequestMapping("/getFoodsByCity")
public String getFoodsByCity(HttpServletRequest req,HttpServletResponse resp){
	

    resp.setContentType("text/html; charset=UTF-8");
    //根据city准确获取食物
    
   String city=req.getParameter("city");
   
   List<Foods> foods=foodsServiceimpl.selFoodsByCity(city);
    req.setAttribute("foods", foods);
    System.out.println("foods:"+foods);
    System.out.println("city:"+city);
	return "/foods_city.jsp";
	
}
@RequestMapping("/getFoodsBySerach")
public String getFoodsBySerach(HttpServletRequest req,HttpServletResponse resp){
	try {
		req.setCharacterEncoding("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    resp.setContentType("text/html; charset=UTF-8");
    //根据city准确获取食物
    
   String search=req.getParameter("search");
   System.out.println("search:"+search);

  
   List<Foods> foods=foodsServiceimpl.selFoodsBySerach(search);
   
    req.setAttribute("foods", foods);
    System.out.println("foods:"+foods);
   
	return "/foods_city.jsp";
	
}
}
