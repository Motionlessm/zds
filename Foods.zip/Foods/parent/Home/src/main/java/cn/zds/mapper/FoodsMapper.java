package cn.zds.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import cn.zds.pojo.Foods;




public interface FoodsMapper {
	//分页获取所有食物
	@Select("select * from my_home limit #{0},#{1}")
	List<Foods> selAllFoods(int pageStart,int pageSize);
	
	//按照城市获取食物
	@Select("select * from my_home where city=#{0}")
	List<Foods> selFoodsByCity(String city);
	
	//获取所有城市
	@Select("select distinct city from my_home")
	List<String> selAllCity();
	
	//根据id获取食物内容
	@Select("select * from my_home where id=#{0}")
	Foods selFoodById(int id);
	
	//根据城市或者名字模糊查询
	@Select("select * from my_home where city like #{0} or cname like #{0}")
	List<Foods> selFoodsBySerach(String serach);
	
	//获取食物的总数量
	@Select("select count(*) from my_home")
	int selAllFoodsCount();
	
}
