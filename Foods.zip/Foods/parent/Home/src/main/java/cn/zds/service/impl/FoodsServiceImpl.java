package cn.zds.service.impl;

import java.rmi.server.UID;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zds.mapper.FoodsMapper;
import cn.zds.mapper.HomeMapper;
import cn.zds.pojo.Foods;
import cn.zds.service.FoodsService;
import cn.zds.service.HomeService;


@Service
public class FoodsServiceImpl implements FoodsService {
	@Resource
	private FoodsMapper foodsMapper;

	@Override
	public List<Foods> selAllFoods(int pageStart,int pageSize) {
		// TODO Auto-generated method stub
		return foodsMapper.selAllFoods(pageStart, pageSize);
	}

	@Override
	public List<Foods> selFoodsByCity(String city) {
		// TODO Auto-generated method stub
		return foodsMapper.selFoodsByCity(city);
	}

	@Override
	public List<String> selAllCity() {
		// TODO Auto-generated method stub
		return foodsMapper.selAllCity();
	}

	@Override
	public Foods selFoodById(String uid) {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(uid);	
		return foodsMapper.selFoodById(id);
	}

	@Override
	public List<Foods> selFoodsBySerach(String serach) {
		serach="%"+serach+"%";
		return foodsMapper.selFoodsBySerach(serach);
	}

	@Override
	public int selAllFoodsCount() {
		// TODO Auto-generated method stub
		return foodsMapper.selAllFoodsCount();
	}

	
	

	

}
