package cn.zds.service;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import cn.zds.pojo.Culture;
import cn.zds.pojo.Foods;;


public interface CultureService {
	//分页获取所有文化
	
	List<Culture> selAllCulture(int pageStart,int pageSize);
	
	//按照城市获取文化
	
	List<Culture> selCultureByCity(String city);
	
	//获取所有城市
	
	List<String> selAllCity();
	
	//根据id获取culture
	
	Culture selCultureById(String id);
	
	//根据城市或者名字模糊查询
	
	List<Culture> selCultureBySerach(String serach);
	
	//获取文化的总数量
	
	int selAllCultureCount();
	
	//获取前9条、
		
		 List<Culture> sel1to9();
	
}
