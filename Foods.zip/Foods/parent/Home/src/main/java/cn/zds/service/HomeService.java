package cn.zds.service;

import java.util.List;


import cn.zds.pojo.Foods;;


public interface HomeService {
	List<Foods> sel1to9();
	
}
