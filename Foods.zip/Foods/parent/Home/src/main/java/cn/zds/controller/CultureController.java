package cn.zds.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.zds.pojo.Culture;
import cn.zds.pojo.Foods;
import cn.zds.pojo.PageInfo;
import cn.zds.service.CultureService;
import cn.zds.service.FoodsService;
import cn.zds.service.HomeService;
@Controller
public class CultureController {
@Resource 
private CultureService cultureServiceimpl;
@RequestMapping("/getAllCulture")
public String getAllCulture(HttpServletRequest req,HttpServletResponse resp){
	try {
		req.setCharacterEncoding("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    resp.setContentType("text/html; charset=UTF-8");
    
    PageInfo pageInfo=new PageInfo();
	pageInfo.setPageSize(9);
	if(req.getParameter("pageNumber")!=null&&!req.getParameter("pageNumber").equals("")){
		pageInfo.setPageNumber(Integer.parseInt(req.getParameter("pageNumber")));
	}
	else {
		pageInfo.setPageNumber(1);
	}
	long count=cultureServiceimpl.selAllCultureCount();
	pageInfo.setTotal(count%pageInfo.getPageSize()==0?count/pageInfo.getPageSize():count/pageInfo.getPageSize()+1);
	System.out.println("pageInfo:"+pageInfo);
	int pageStart=pageInfo.getPageSize()*(pageInfo.getPageNumber()-1);
	int pageSize=pageInfo.getPageSize();
	
	
    //获取全部食物 
    List<Culture> cultures=cultureServiceimpl.selAllCulture(pageStart, pageSize);
    req.setAttribute("cultures", cultures);
    req.setAttribute("pageInfo", pageInfo);
    System.out.println("cultures:"+cultures);
    //获取全部城市

    
    
    
	return "/cultures_city.jsp";
	
}

@RequestMapping("/getCdCuture")
public String getCdFood(HttpServletRequest req,HttpServletResponse resp){
	try {
		req.setCharacterEncoding("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    resp.setContentType("text/html; charset=UTF-8");
    //根据id准确获取食物
   
   String id=req.getParameter("id");
   Culture culture=cultureServiceimpl.selCultureById(id);
    req.setAttribute("culture", culture);
    System.out.println("culture:"+culture);
    
	return "/cd_culture.jsp";
	
}

@RequestMapping("/getCultureByCity")
public String getFoodsByCity(HttpServletRequest req,HttpServletResponse resp){

	try {
		req.setCharacterEncoding("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    resp.setContentType("text/html; charset=UTF-8");
    //根据city准确获取食物
    
   String city=req.getParameter("city");
 //这是window上运行，linux需要删除
   
   List<Culture> cultures=cultureServiceimpl.selCultureByCity(city);
    req.setAttribute("cultures", cultures);
    System.out.println("cultures:"+cultures);
    System.out.println("city:"+city);
	return "/cultures_city.jsp";
	
}
@RequestMapping("/getCultureBySerach")
public String getCultureBySerach(HttpServletRequest req,HttpServletResponse resp){
	try {
		req.setCharacterEncoding("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    resp.setContentType("text/html; charset=UTF-8");
    //根据city准确获取食物
    
   String search=req.getParameter("search");
   System.out.println("search:"+search);

  
   List<Culture> cultures=cultureServiceimpl.selCultureBySerach(search);
   
    req.setAttribute("cultures", cultures);
    System.out.println("cultures:"+cultures);
   
	return "/cultures_city.jsp";
	
}
}
