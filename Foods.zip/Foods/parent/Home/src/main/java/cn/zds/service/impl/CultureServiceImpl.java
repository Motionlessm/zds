package cn.zds.service.impl;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zds.mapper.CultureMapper;
import cn.zds.pojo.Culture;
import cn.zds.pojo.Foods;
import cn.zds.service.CultureService;



@Service
public class CultureServiceImpl implements CultureService {
	@Resource
	private CultureMapper cultureMapper;

	@Override
	public List<Culture> selAllCulture(int pageStart, int pageSize) {
		// TODO Auto-generated method stub
		return cultureMapper.selAllCulture(pageStart, pageSize);
	}

	@Override
	public List<Culture> selCultureByCity(String city) {
		// TODO Auto-generated method stub
		return cultureMapper.selCultureByCity(city);
	}

	@Override
	public List<String> selAllCity() {
		// TODO Auto-generated method stub
		return cultureMapper.selAllCity();
	}

	@Override
	public Culture selCultureById(String uid) {
		int id=Integer.parseInt(uid);
		return cultureMapper.selCultureById(id);
	}

	@Override
	public List<Culture> selCultureBySerach(String serach) {
		
		serach="%"+serach+"%";
		// TODO Auto-generated method stub
		return cultureMapper.selCultureBySerach(serach);
	}

	@Override
	public int selAllCultureCount() {
		// TODO Auto-generated method stub
		return cultureMapper.selAllCultureCount();
	}

	@Override
	public List<Culture> sel1to9() {
		// TODO Auto-generated method stub
		return cultureMapper.sel1to9();
	}

	

	

}
