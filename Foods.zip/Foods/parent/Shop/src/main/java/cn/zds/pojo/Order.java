package cn.zds.pojo;

public class Order {

private String cp;
//购买人
private String tel;
//购买人电话
private String address;
//购买人地址ַ
private String cid;
//订单号
private int id;
//订单id
private int ccid;
//商品id
private double cprice;
//商品价格
private String shopname;
//商品名
public String getCp() {
	return cp;
}
public void setCp(String cp) {
	this.cp = cp;
}
public String getTel() {
	return tel;
}
public void setTel(String tel) {
	this.tel = tel;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getCcid() {
	return ccid;
}
public void setCcid(int ccid) {
	this.ccid = ccid;
}
public double getCprice() {
	return cprice;
}
public void setCprice(double cprice) {
	this.cprice = cprice;
}
public String getShopname() {
	return shopname;
}
public void setShopname(String shopname) {
	this.shopname = shopname;
}
@Override
public String toString() {
	return "Order [cp=" + cp + ", tel=" + tel + ", address=" + address
			+ ", cid=" + cid + ", id=" + id + ", ccid=" + ccid + ", cprice="
			+ cprice + ", shopname=" + shopname + "]";
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((address == null) ? 0 : address.hashCode());
	result = prime * result + ccid;
	result = prime * result + ((cid == null) ? 0 : cid.hashCode());
	result = prime * result + ((cp == null) ? 0 : cp.hashCode());
	long temp;
	temp = Double.doubleToLongBits(cprice);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	result = prime * result + id;
	result = prime * result + ((shopname == null) ? 0 : shopname.hashCode());
	result = prime * result + ((tel == null) ? 0 : tel.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Order other = (Order) obj;
	if (address == null) {
		if (other.address != null)
			return false;
	} else if (!address.equals(other.address))
		return false;
	if (ccid != other.ccid)
		return false;
	if (cid == null) {
		if (other.cid != null)
			return false;
	} else if (!cid.equals(other.cid))
		return false;
	if (cp == null) {
		if (other.cp != null)
			return false;
	} else if (!cp.equals(other.cp))
		return false;
	if (Double.doubleToLongBits(cprice) != Double
			.doubleToLongBits(other.cprice))
		return false;
	if (id != other.id)
		return false;
	if (shopname == null) {
		if (other.shopname != null)
			return false;
	} else if (!shopname.equals(other.shopname))
		return false;
	if (tel == null) {
		if (other.tel != null)
			return false;
	} else if (!tel.equals(other.tel))
		return false;
	return true;
}
}