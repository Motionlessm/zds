package cn.zds.mapper;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.zds.pojo.Shop;

public class ShopDaoImpl {
	public static List<Shop> selAllshopdao(String screen, String price,
			String commodity_type,String serach) {
		// TODO Auto-generated method stub
		java.sql.Connection conn=null;
		java.sql.PreparedStatement ps=null;
		ResultSet rs=null;
		List<Shop> s=new ArrayList<>();
		try {
			
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
		
			String sql=null;
			
			if("%%".equals(serach)){
				if("low".equals(price)){
					
					if("cprice".equals(screen)){
						sql="select * from my_shop where cprice>0 and cprice<=30  and clc= ? order by cprice";
					}
					else{
						sql="select * from my_shop where cprice>0 and cprice<=30  and clc= ? order by doh desc";
					}
					
				}
				else if("mid".equals(price)){
					if("cprice".equals(screen)){
						sql="select * from my_shop where cprice>30 and cprice<=80  and clc= ? order by cprice";
					}
					else{
						sql="select * from my_shop where cprice>30 and cprice<=80  and clc= ? order by doh desc";
					}
					 
				}
				else  if("height".equals(price)){
					if("cprice".equals(screen)){
						sql="select * from my_shop where cprice>80   and clc= ? order by cprice";
					}
					else{
						sql="select * from my_shop where cprice>80  and clc= ? order by doh desc";
					}
				}
				else{
					if("cprice".equals(screen)){
						sql="select * from my_shop where   clc= ? order by cprice";
					}
					else{
						sql="select * from my_shop where  clc= ? order by doh desc";
					}
				}
			}
			else {
				
						sql="select * from my_shop where  cname like ? order by cprice";
					
			}

			ps=conn.prepareStatement(sql);
			
			ps.setString(1, commodity_type);
			if(!("%%".equals(serach)||serach==null)){
				ps.setString(1, serach);
			}
			System.out.println(ps);
			rs=ps.executeQuery();
			while(rs.next()){
				Shop s1=new Shop();
				s1.setId(rs.getInt("id"));
				s1.setCname(rs.getString("cname"));
				s1.setClc(rs.getString("clc"));
				s1.setCprice(rs.getDouble("cprice"));
				s1.setCstock(rs.getInt("cstock"));
				s1.setBd(rs.getString("bd"));
				s1.setCp(rs.getString("cp"));
				s1.setDp1(rs.getString("dp1"));
				s1.setDp2(rs.getString("dp2"));
				s1.setDp3(rs.getString("dp3"));
				s1.setDn(rs.getString("dn"));
				s1.setTel(rs.getString("tel"));
				s1.setDoh(rs.getInt("doh"));
				s1.setCity(rs.getString("city"));
				s.add(s1);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally{
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return s;
	}
}
