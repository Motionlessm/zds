package cn.zds.service;

import java.util.List;


import cn.zds.pojo.User;


public interface UserService {
	//通过用户名密码获取用户信息
		
		User selChickUser(String uname,String pwd);
		//通过uid获取用户信息（用在三天免登录）
		
		User selChickUid(String uid);
		//更新user
		
		int updateUser(User user);
		//插入user
		
		int insertUser(User u_register);
		//超级用户更新user
		int updateUserBySuper(User user);
		//超级用户查询所有用户
	
		List<User> selAllUsers();
		//delet User
		int delUser(User user);
		//通过uanem 查找users
		List<User>selAllUsersBySerach(String uname);
		//超级用户登录
		User selSupUser(String uname,String pwd);
}
