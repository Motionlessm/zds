package cn.zds.pojo;

public class User {
	private String uname;
	private String password;
	private int id;
	private String tel;
	private String address;
	private String commodity;//商品
	private String hp;//头像
	private String sp;//密保
	private String ap;//密保问题
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCommodity() {
		return commodity;
	}
	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}
	public String getHp() {
		return hp;
	}
	public void setHp(String hp) {
		this.hp = hp;
	}
	public String getSp() {
		return sp;
	}
	public void setSp(String sp) {
		this.sp = sp;
	}
	public String getAp() {
		return ap;
	}
	public void setAp(String ap) {
		this.ap = ap;
	}
	@Override
	public String toString() {
		return "User [uname=" + uname + ", password=" + password + ", id=" + id + ", tel=" + tel + ", address="
				+ address + ", commodity=" + commodity + ", hp=" + hp + ", sp=" + sp + ", ap=" + ap + "]";
	}


}
