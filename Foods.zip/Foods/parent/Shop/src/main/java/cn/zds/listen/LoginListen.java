package cn.zds.listen;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


public class LoginListen implements HttpSessionListener,ServletContextListener {

	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void contextInitialized(ServletContextEvent contextEvent) {
		ServletContext sc = contextEvent.getServletContext();
		sc.setAttribute("count", 0);
		
	}

	public void sessionCreated(HttpSessionEvent sessionEvent) {
		ServletContext sc = sessionEvent.getSession().getServletContext();	
		int count=	(Integer) sc.getAttribute("count");
		sc.setAttribute("count", ++count);
		
	}

	public void sessionDestroyed(HttpSessionEvent sessionEvent) {
		ServletContext sc = sessionEvent.getSession().getServletContext();
		int count=	 (Integer) sc.getAttribute("count");
		sc.setAttribute("count", --count);
		System.out.println("我是session毁灭");
		
		
	}

}
