package cn.zds.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import cn.zds.pojo.Order;



public interface OrderMapper {
	//通过购买人获取商品
	@Select("select * from my_order where cp=#{0}")
	List<Order> selGetOrderbyName(String uname);
	//插入订单信息
	@Insert("insert into my_order (cp,tel,address,cid,cprice,shopname,ccid) values(#{cp},#{tel},#{address},#{cid},#{cprice},#{shopname},#{ccid})")
	void insOrder(Order order);
	//根据订单号删除订单
	@Delete("delete from my_order where cid=#{cid}")
	int delOrder(Order order);
	//更新订单
	@Update("update my_order set tel=#{tel} , address=#{address} where cid=#{cid}")
	int updOrder(Order order);
	//拿到所有的订单
	@Select("select * from my_order")
	List<Order> selAllOrders();
	
	@Select("select * from my_order where cid=#{0} or cp=#{1} or shopname like #{2}")
	List<Order> selAllOrdersBySerach(String cid,String cp,String shopname);
}
