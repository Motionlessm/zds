package cn.zds.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zds.mapper.ShopMapper;
import cn.zds.pojo.Shop;
import cn.zds.service.ShopService;
@Service
public class ShopServiceImpl implements ShopService {
	@Resource
	private ShopMapper shopMapper;


	public Shop selCdByIdShop(String id) {
		// TODO Auto-generated method stub
		return shopMapper.selCdByIdShop(id);
	}

	public List<Shop> selAllshop(String screen, String price, String commodity_type, String serach) {
		// TODO Auto-generated method stub
		
		Map< String, String> map=new HashMap<String, String>();
		map.put("screen", screen);
		map.put("price", price);
		map.put("commodity_type", commodity_type);
		map.put("serach", serach);
		return shopMapper.selAllshopdao(screen);
	}

	public List<Shop> SelAllShop(String search) {
		// TODO Auto-generated method stub
		return shopMapper.SelAllShop(search);
	}

	@Override
	public int delShop(Shop shop) {
		// TODO Auto-generated method stub
		return shopMapper.delShop(shop);
	}

	@Override
	public List<Shop> selAllShopsBySerach(String cname) {
		// TODO Auto-generated method stub
		cname="%"+cname+"%";
		return shopMapper.selAllShopsBySerach(cname);
	}


	@Override
	public int updataShop(Shop shop) {
		// TODO Auto-generated method stub
		return shopMapper.updataShop(shop);
	}

	@Override
	public int insertShop(Shop shop) {
		// TODO Auto-generated method stub
		return shopMapper.insertShop(shop);
	}

	@Override
	public List<String> selAllClc() {
		// TODO Auto-generated method stub
		return shopMapper.selAllClc();
	}

	@Override
	public int updShopDohById(String id) {
		// TODO Auto-generated method stub
		 int ccid=Integer.parseInt(id);//转换一下类型
		return  shopMapper.updShopDohById(ccid);
	}

	@Override
	public int selAllShopCount() {
		// TODO Auto-generated method stub
		return shopMapper.selAllShopCount();
	}

	@Override
	public List<Shop> selAllShop(int pageStart, int pageSize) {
		// TODO Auto-generated method stub
		//return shopMapper.selAllShop(pageStart, pageSize);
		return null;
	}

	@Override
	public int updDnShop(String id) {
		// TODO Auto-generated method stub
		 int ccid=Integer.parseInt(id);//转换一下类型
			return  shopMapper.updDnShop(ccid);
	}

	@Override
	public List<Shop> selAllShoporacle(int end, int start) {
		// TODO Auto-generated method stub
		return shopMapper.selAllShoporacle(end, start);
	}

	



	




}
