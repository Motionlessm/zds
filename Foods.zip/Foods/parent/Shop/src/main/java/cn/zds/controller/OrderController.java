package cn.zds.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

import cn.zds.pojo.Order;
import cn.zds.pojo.User;
import cn.zds.service.OrderService;
import cn.zds.service.ShopService;


@Controller
public class OrderController {
	@Resource 
	private OrderService orderServiceImpl;
	@Resource 
	private ShopService shopServiceImpl;
	@RequestMapping("/servlet/buyservlet")
	public String buy(HttpServletRequest req,HttpServletResponse resp) throws IOException{

	String bath = req.getContextPath();
	HttpSession session = req.getSession();
	User user=(User) session.getAttribute("user");
	Order order = new Order();
	if (session.getAttribute("before_order") != null) {
		order = (Order) session.getAttribute("before_order");//准备订单不为空
	}
	if (req.getParameter("oper") != null) {//操作符不为空

		if (req.getParameter("oper").equals("go_to_buy.jsp")) {//去支付
			
			if((user.getTel()==null||"".equals(user.getTel()))
					||(user.getAddress()==null||"".equals(user.getAddress()))){//个人信息不完善
				session.setAttribute("msg_user", "请先完善个人信息，联系方式与地址为必须");
				
				return "redirect:/myselfcontroal.jsp";
			}

			
			return "/buy.jsp";
		} else if (req.getParameter("oper").equals("go_to_pay")) {//支付
			order.setAddress(new String(req.getParameter("address").getBytes("ISO-8859-1"),"UTF-8"));
			order.setCprice(Double.parseDouble(req.getParameter("cprice")));
			order.setTel((((User) session
					.getAttribute("user")).getTel().trim()));
			order.setCp(((User) session.getAttribute("user")).getUname());
			order.setCcid(Integer.parseInt(req.getParameter("ccid")));
			order.setShopname(new String(req.getParameter("shopname").getBytes("ISO-8859-1"),"UTF-8"));
			//将完整的订单信息放入before_order
			String shopid =req.getParameter("ccid");//拿到要购买的商品的id
			System.out.println(shopid);
			session.setAttribute("shopid", shopid);//放到session 给后面增加商品热度用
			session.setAttribute("before_order", order);
			System.out.println(order.getShopname());
			
			return "/alipay/index.jsp";

		} else if (req.getParameter("oper").equals("write_into_oder")) {// 获取订单号

			order.setCid(req.getParameter("name"));
			session.setAttribute("before_order", order);
			resp.getWriter().write(new Gson().toJson(order));

		} else if (req.getParameter("oper").equals("write")) {//支付完成，写入订单表
	
			orderServiceImpl.insOrder(order);
			System.out.println(req.getSession().getAttribute("shopid"));
			//更新热度
			String shopid=(String) req.getSession().getAttribute("shopid");
			shopServiceImpl.updShopDohById(shopid);
			//更新库存
			shopServiceImpl.updDnShop(shopid);
			return "/servlet/loginservlet?oper=del_shop&shop_id="
					+ order.getCcid() + "";//删除购物车中已经买过的物品


		}

		else if (req.getParameter("oper").equals("getall")) {
		//通过用户名找所有订单
			if (session.getAttribute("user") != null) {
				User hs = (User) session.getAttribute("user");
				List<Order> os = orderServiceImpl.selGetOrderbyName(hs.getUname());
				session.setAttribute("order", os);// �����ݿ��ж�ȡ�Ķ���
				
				return "/order.jsp";
			}
		}
	}
	return "/Login.jsp";
	
	}
	
	
	@RequestMapping("/servlet/delOrder")
	@ResponseBody
	public void deOrder(HttpServletRequest req,HttpServletResponse resp){
		//ajax删除订单（超级用户用）
		
		 Gson gson = new Gson();
		 //获取前端传来的订单
		    Object res = gson.fromJson(req.getParameter("order"), Order.class);
		    Order order=new Order();
		    order=(Order) res;
		   //删除订单
		    int index = orderServiceImpl.delOrder(order);
		   
 	}
	
	@RequestMapping("/servlet/updateOrder")
	@ResponseBody
	public void updateOrder(HttpServletRequest req,HttpServletResponse resp){
		
		//ajax 更新订单
		 Gson gson = new Gson();
		 //获取前端出来的订单
		    Object res = gson.fromJson(req.getParameter("order"), Order.class);
		    Order order=new Order();
		    order=(Order) res;
		    //更新自数据库
		    int index = orderServiceImpl.updOrder(order);
		   
 	}
	//获取所有订单
	@RequestMapping("/servlet/getAllOrders")
	public String getAllOrders(HttpServletRequest req,HttpServletResponse resp){
		req.setAttribute("orders", orderServiceImpl.selAllOrders());
		
		 return "/super/order.jsp";
 	}
	//模糊搜索订单
	@RequestMapping("/servlet/orderSerach")
	public String getOrdersBySerach(HttpServletRequest req,HttpServletResponse resp){
		
		try {
			req.setCharacterEncoding("UTF-8");
			resp.setContentType("text/html; charset=UTF-8");
			String cid=req.getParameter("orderSerach")+"";
			String cp=req.getParameter("orderSerach")+"";
			String shopname=req.getParameter("orderSerach")+"";
			//通过信息检索订单
			req.setAttribute("orders", orderServiceImpl.selAllOrdersBySerach(cid, cp, shopname));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        
		return "/super/order.jsp";
		
	}
}
