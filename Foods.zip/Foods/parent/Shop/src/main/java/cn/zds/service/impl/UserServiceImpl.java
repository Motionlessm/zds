package cn.zds.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import cn.zds.mapper.UserMapper;
import cn.zds.pojo.User;
import cn.zds.service.UserService;
@Controller
public class UserServiceImpl implements UserService{
	@Resource
	private UserMapper userMapper;
	public User selChickUser(String uname, String pwd) {
		// TODO Auto-generated method stub
		return userMapper.selChickUser(uname, pwd);
	}

	public User selChickUid(String uid) {
		// TODO Auto-generated method stub
		return userMapper.selChickUid(uid);
	}

	public int updateUser(User user) {
		// TODO Auto-generated method stub
		return userMapper.updateUser(user);
	}

	public int insertUser(User u_register) {
		// TODO Auto-generated method stub
		return userMapper.insertUser(u_register);
	}

	@Override
	public int updateUserBySuper(User user) {
		// TODO Auto-generated method stub
		return userMapper.updateUserBySuper(user);
	}

	@Override
	public List<User> selAllUsers() {
		// TODO Auto-generated method stub
		return userMapper.selAllUsers();
	}

	@Override
	public int delUser(User user) {
		// TODO Auto-generated method stub
		return userMapper.delUser(user);
	}

	@Override
	public List<User> selAllUsersBySerach(String uname) {
		// TODO Auto-generated method stub
		uname="%"+uname+"%";
		return userMapper.selAllUsersBySerach(uname);
	}

	@Override
	public User selSupUser(String uname, String pwd) {
		// TODO Auto-generated method stub
		return userMapper.selSupUser(uname, pwd);
	}
	


}
