package cn.zds.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class LoginInterceptor implements HandlerInterceptor{

	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

	public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object arg2) throws Exception {
		String url=req.getRequestURI();
		System.out.println(url);
		if(url.equals("/servlet/loginservlet")||url.equals("/servlet/ck")||url.equals("/Login.jsp")||url.endsWith(".css")||url.endsWith(".jpg")||url.endsWith(".png")||url.endsWith(".js")||url.endsWith(".webp")||url.endsWith(".jsp")){
			req.setCharacterEncoding("UTF-8");

	        resp.setContentType("text/html; charset=UTF-8");
			return true;
		}else {
			HttpSession session = req.getSession();
			Object attribute = session.getAttribute("user");
			if(attribute!=null){
				req.setCharacterEncoding("UTF-8");
				
		        resp.setContentType("text/html; charset=UTF-8");
				return true;
			}
			resp.sendRedirect("/Login.jsp");
			return false;
		}
		
	}
	

}
