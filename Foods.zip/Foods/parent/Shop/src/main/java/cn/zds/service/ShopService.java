package cn.zds.service;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import cn.zds.pojo.Shop;

public interface ShopService {
	// 获取全部商品mysql写法

	List<Shop> selAllShop(int pageStart,int pageSize);
	
	//获取全部商品 oracle写法
	List<Shop> selAllShoporacle(int end,int start);
	// 根据商品id获取商品

	Shop selCdByIdShop(String id);

	// 通过赛选信息获取商品
	List<Shop> selAllshop(String screen, String price, String commodity_type, String serach);
	// 模糊筛选商品

	List<Shop> SelAllShop(String search);

	// delet Shop

	int delShop(Shop shop);
	// 根据用户名或者分类查找Shop

	List<Shop> selAllShopsBySerach(String cname);

	// 插入shop
	int insertShop(Shop shop);
	
	//更新ushop
	int updataShop(Shop shop);
	//查询所有分类
	List<String>selAllClc();
	//根据id跟新商品热度
	int updShopDohById(String id);
	
	//获取所有商品总数量
	
	int selAllShopCount();
	
	//更新库存
	int updDnShop(String id);
}
