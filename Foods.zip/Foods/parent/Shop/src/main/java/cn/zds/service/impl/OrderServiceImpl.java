package cn.zds.service.impl;

import java.rmi.server.UID;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zds.mapper.OrderMapper;
import cn.zds.pojo.Order;
import cn.zds.pojo.Shop;
import cn.zds.service.OrderService;
import cn.zds.service.ShopService;
@Service
public class OrderServiceImpl implements OrderService {
	@Resource
	private OrderMapper orderMapper;
	public List<Order> selGetOrderbyName(String uname) {
		// TODO Auto-generated method stub
		return orderMapper.selGetOrderbyName(uname);
	}

	public void insOrder(Order order) {
		orderMapper.insOrder(order);
	}

	@Override
	public int delOrder(Order order) {
		// TODO Auto-generated method stub
		return orderMapper.delOrder(order);
	}

	@Override
	public int updOrder(Order order) {
		// TODO Auto-generated method stub
		return orderMapper.updOrder(order);
	}

	@Override
	public List<Order> selAllOrders() {
		// TODO Auto-generated method stub
		return orderMapper.selAllOrders();
	}

	@Override
	public List<Order> selAllOrdersBySerach(String cid, String cp, String shopname) {
		// TODO Auto-generated method stub
		shopname="%"+shopname+"%";
		
		return orderMapper.selAllOrdersBySerach(cid, cp, shopname);
	}

	

}
