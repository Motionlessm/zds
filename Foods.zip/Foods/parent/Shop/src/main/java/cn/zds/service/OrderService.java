package cn.zds.service;

import java.util.List;


import cn.zds.pojo.Order;


public interface OrderService {
	
	List<Order> selGetOrderbyName(String uname);
	
	void insOrder(Order order);
	
	int delOrder(Order order);
	int updOrder(Order order);
	List<Order> selAllOrders();
	List<Order> selAllOrdersBySerach(String cid,String cp,String shopname);
}
