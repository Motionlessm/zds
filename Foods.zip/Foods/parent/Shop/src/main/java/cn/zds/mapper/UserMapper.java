package cn.zds.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import cn.zds.pojo.User;

public interface UserMapper {
	//通过用户名密码获取用户信息
	@Select("select * from my_user where uname=#{0} and password=#{1}")
	User selChickUser(String uname,String pwd);
	//通过uid获取用户信息（用在三天免登录）
	@Select("select * from my_user where id=#{0}")
	User selChickUid(String uid);
	//更新user
	//jdbcType=VARCHAR为mybatis识别内容为null（让他认识null）
	@Update("update my_user set uname=#{uname,jdbcType=VARCHAR} , password=#{password,jdbcType=VARCHAR} , tel=#{tel,jdbcType=VARCHAR} ,"
			+ " address=#{address,jdbcType=VARCHAR} , commodity=#{commodity,jdbcType=VARCHAR} , hp=#{hp,jdbcType=VARCHAR}, sp=#{sp,jdbcType=VARCHAR} , ap=#{ap,jdbcType=VARCHAR} "
			+ "where id=#{id}")
	int updateUser(User user);
	//插入user
	@Insert("insert into my_user (uname,password,tel) values(#{uname},#{password},#{tel})")
	int insertUser(User u_register);
	//根据超级用户跟新user
	@Update("update my_user set uname=#{uname} , password=#{password} , tel=#{tel} ,"
			+ " address=#{address} "
			+ "where id=#{id}")
	int updateUserBySuper(User user);
	//超级用户查询所有用户
	@Select("select * from my_user")
	List<User> selAllUsers();
	//delet User
	@Delete("DELETE FROM my_user where id=#{id}")
	int delUser(User user);
	//根据uanme查找users
	@Select("select * from my_user where uname like #{0}")
	List<User>selAllUsersBySerach(String uname); 
	
	//超级用户登录
	@Select("select * from super_user where uname=#{0} and password=#{1}")
	User selSupUser(String uname,String pwd);
}
