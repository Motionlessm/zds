package cn.zds.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import cn.zds.pojo.Shop;
import cn.zds.pojo.User;

public interface ShopMapper {
	//获取全部商品 mysql写法
	@Select("select * from my_shop limit #{0},#{1}")
	List<Shop> selAllShop(int pageStart,int pageSize);
	//获取全部商品 oracle写法
		@Select("select * from (select rownum rn,a.* from my_shop a where rownum <=#{0} ) where rn >= #{1}")
		List<Shop> selAllShoporacle(int end,int start);
	//根据商品id获取商品
	@Select("select * from my_shop where id=#{0}")
	Shop selCdByIdShop(String id);
	//通过赛选信息获取商品
	List<Shop> selAllshopdao(String test);
	//模糊筛选商品
	@Select("select * from my_shop where cname like #{0} order by doh desc")
	List<Shop> SelAllShop(String search);
	
	//delet Shop
		@Delete("DELETE FROM my_shop where id=#{id}")
		int delShop(Shop shop);
		//根据用户名或者分类查找Shop
		@Select("select * from my_shop where cname like #{0} or clc like#{0}")
		List<Shop>selAllShopsBySerach(String cname); 
		//插入shop
		

		@Insert("insert into my_shop (cname,clc,cprice,cstock,bd,cp,dp1,dp2,dp3,dn,tel,city) values(#{cname},#{clc},#{cprice},#{cstock},#{bd},#{cp},#{dp1},#{dp2},#{dp3},#{dn},#{tel},#{city})")
		int insertShop(Shop shop);
		//更新shop
		@Update("update my_shop set cname=#{cname},clc=#{clc},cprice=#{cprice},cstock=#{cstock},bd=#{bd},"
				+ "cp=#{cp},dp1=#{dp1},dp2=#{dp2},dp3=#{dp3},dn=#{dn},tel=#{tel},city=#{city} where id=#{id}")
		
		
		int updataShop(Shop shop);
		//查询所有分类
		@Select("select distinct clc from my_shop ")
		List<String>selAllClc();
		//购买成功后给指定商品增加热度
		@Update("update my_shop set doh=doh+1 where id=#{0}")
		int updShopDohById(int id);
		//获取所有商品总数量
		@Select("select count(*) from my_shop")
		int selAllShopCount();
		//更新库存
		@Update("update my_shop set cstock=cstock-1 where id=#{0}")
		int updDnShop(int id);
}
