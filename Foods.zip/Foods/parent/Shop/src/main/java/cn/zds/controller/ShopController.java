package cn.zds.controller;



import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;

import cn.zds.mapper.ShopDaoImpl;
import cn.zds.mapper.ShopMapper;
import cn.zds.pojo.Order;
import cn.zds.pojo.PageInfo;
import cn.zds.pojo.Shop;
import cn.zds.pojo.User;
import cn.zds.service.ShopService;






@Controller
public class ShopController {
	@Resource
	private ShopService shopServiceImpl;
	
	@RequestMapping("/servlet/main")
	//商品主页
	private String main(HttpServletRequest req,HttpServletResponse rep){
		try {
			req.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	String bath = req.getContextPath();
	HttpSession session = req.getSession();
	List<Shop> s=new ArrayList<Shop>();
	Order before_order=new Order();
	session.setAttribute("before_order", before_order);
	//获取所有分类
	List<String> clcs = shopServiceImpl.selAllClc();
	req.setAttribute("clcs", clcs);
	PageInfo pageInfo=new PageInfo();
	pageInfo.setPageSize(8);//一页的数量
	if(req.getParameter("price")==null&&req.getParameter("commodity_type")==null&&(req.getParameter("iflike")==null)||req.getParameter("iflike").equals("")){//非模糊搜索
		
		
		if(req.getParameter("pageNumber")!=null&&!req.getParameter("pageNumber").equals("")){
			pageInfo.setPageNumber(Integer.parseInt(req.getParameter("pageNumber")));
		}
		else {
			pageInfo.setPageNumber(1);//初始化为第一页
		}
		long count=shopServiceImpl.selAllShopCount();//总商品数量
		//总页数
		pageInfo.setTotal(count%pageInfo.getPageSize()==0?count/pageInfo.getPageSize():count/pageInfo.getPageSize()+1);
		System.out.println("pageInfo:"+pageInfo);
		//mysql的分页写法
		//int pageStart=pageInfo.getPageSize()*(pageInfo.getPageNumber()-1);
		//int pageSize=pageInfo.getPageSize();
		//System.out.println(pageStart+":"+pageSize);
		// s=shopServiceImpl.selAllShop(pageStart,pageSize);
		
		//oracle的分页写法
		 	int end=pageInfo.getPageSize()*(pageInfo.getPageNumber());
			int start=pageInfo.getPageSize()*(pageInfo.getPageNumber()-1)+1;
			
			System.out.println("end:"+end+" "+"start:"+start);
			s=shopServiceImpl.selAllShoporacle(end, start);

	}
	else{
	
		//模糊搜索
		if(req.getParameter("search")!=null||"".equals(req.getParameter("search"))){
			
			String search="%"+req.getParameter("search")+"%";
			s=ShopDaoImpl.selAllshopdao(req.getParameter("screen"),req.getParameter("price"),req.getParameter("commodity_type"),search);
			
		}
		
	}

	session.setAttribute("shop",s );//shop表示的是商品列表（就很多商品）
	session.setAttribute("pageInfo", pageInfo);
	ServletContext sc = req.getServletContext();

	return "/shop_home.jsp";
	
}
	
	@RequestMapping("/servlet/getcdservlet")
	private String getcd(HttpServletRequest req,HttpServletResponse resp){
	//通过商品id获取商品详细信息
		String bath = req.getContextPath();
		
		Shop shop = shopServiceImpl.selCdByIdShop(req.getParameter("id"));

		if (shop != null) {
			req.setAttribute("shop2", shop);//shop2表示一个商品的详细信息
			
			return "/cd.jsp";
		}
		return "/Lodon.jsp";

	}
	
	
	
	/**超级用户管理shop***/
	//获取全部商品
	@RequestMapping("/servlet/getAllShops")

	public String getAllShops(HttpServletRequest req,HttpServletResponse resp){
			PageInfo pageInfo=new PageInfo();
			pageInfo.setPageSize(8);
			if(req.getParameter("pageNumber")!=null&&!req.getParameter("pageNumber").equals("")){
				pageInfo.setPageNumber(Integer.parseInt(req.getParameter("pageNumber")));
			}
			else {
				pageInfo.setPageNumber(1);
			}
			long count=shopServiceImpl.selAllShopCount();
			pageInfo.setTotal(count%pageInfo.getPageSize()==0?count/pageInfo.getPageSize():count/pageInfo.getPageSize()+1);
			System.out.println("pageInfo:"+pageInfo);
			//mysql写法
			//int pageStart=pageInfo.getPageSize()*(pageInfo.getPageNumber()-1);
			//int pageSize=pageInfo.getPageSize();
			
			//oracle写法
			int end=pageInfo.getPageSize()*(pageInfo.getPageNumber());
			int start=pageInfo.getPageSize()*(pageInfo.getPageNumber()-1)+1;
			
			System.out.println("end:"+end+" "+"start:"+start);
			List<Shop> shops=shopServiceImpl.selAllShoporacle(end, start);
			req.setAttribute("shops", shops);
			req.setAttribute("pageInfo", pageInfo);
			return "/super/shop.jsp";
 	}
	//删除某商品
	@RequestMapping("/servlet/delShop")
	@ResponseBody
	public void delShop(HttpServletRequest req,HttpServletResponse resp){
		
		
		 Gson gson = new Gson();
		    Object res = gson.fromJson(req.getParameter("shop"), Shop.class);
		    Shop shop=new Shop();
		    shop=(Shop) res;
		    System.out.println(shop);
		    int index = shopServiceImpl.delShop(shop);
		   
 	}
	//搜索某商品
	@RequestMapping("/servlet/shopSerach")
	public String shopSerach(HttpServletRequest req,HttpServletResponse resp){
		
	
			try {
				req.setCharacterEncoding("utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String cname=req.getParameter("shopSerach")+"";
			System.out.println(cname);
			System.out.println(req.getParameter("shopSerach")+"");
			req.setAttribute("shops", shopServiceImpl.selAllShopsBySerach(cname));
			req.setAttribute("shopSerach", cname);

        
		return "/super/shop.jsp";
		
	}
	//留着
	@RequestMapping("/servlet/updateShop2")
	@ResponseBody
	public void updateShop(HttpServletRequest req,HttpServletResponse resp){

		 Gson gson = new Gson();
		    Object res = gson.fromJson(req.getParameter("shop"), Shop.class);
		   Shop res2=(Shop) res;
		   System.out.println( "res2:"+res2);
		    Shop shop=new Shop();
		    shop=  shopServiceImpl.selCdByIdShop(res2.getId()+"");
		    shop.setBd(res2.getBd());
		    shop.setClc(res2.getClc());
		    shop.setCname(res2.getCname());
		    shop.setCprice(res2.getCprice());
		    shop.setCstock(res2.getCstock());
		    shop.setDn(res2.getDn());
		    shop.setDoh(res2.getDoh());
		    shop.setTel(res2.getTel());
		   
		    System.out.println("shop:"+shop);
		    int index=shopServiceImpl.updataShop(shop);
		    System.out.println(index);

        
	
		
	}
	//更新商品，获取商品id 查找到改商品全部消息，跳转到修改页面
	@RequestMapping("/servlet/updateShop")
	
	public String uploadFile(HttpServletRequest req,HttpServletResponse resp){
		String id = req.getParameter("id");
		Shop shop = shopServiceImpl.selCdByIdShop(id);
		req.setAttribute("updateShop", shop);
		
		return "/super/updateShop.jsp";
	}
	
	//获取修改页面传来的数据，更新到数据库
	@RequestMapping("/servlet/update2Db")
	public String uploadUser(HttpServletRequest req,HttpServletResponse resp,MultipartFile filecp,MultipartFile filedp1,MultipartFile filedp2,MultipartFile filedp3) throws UnsupportedEncodingException{
		
			HttpSession session = req.getSession();
			String id = req.getParameter("id");
			//通过商品id去数据库查找改商品，并且付给shop
			Shop shop = shopServiceImpl.selCdByIdShop(id);
			if(!filecp.getOriginalFilename().equals("")){//封面图不为空
				String fileName = new Date().getTime()+filecp.getOriginalFilename().substring(filecp.getOriginalFilename().lastIndexOf("."));
				//当前时间与后缀作为图片名的新名字
				String path = req.getServletContext().getRealPath("//shops_images")+"/"+fileName;
				
				try {
					//将文件流写入服务器
					FileUtils.copyInputStreamToFile(filecp.getInputStream(), new File(path));
				} catch (IOException e) {
					e.printStackTrace();
				} 
				//设置shop的封面图路径
				shop.setCp("/shops_images/"+fileName);
			}
			if(!filedp1.getOriginalFilename().equals("")){
				//详情图1
				String fileName = new Date().getTime()+filedp1.getOriginalFilename().substring(filedp1.getOriginalFilename().lastIndexOf("."));
				
				String path = req.getServletContext().getRealPath("//shops_images")+"/"+fileName;
				//System.out.println(path);
				try {
					FileUtils.copyInputStreamToFile(filedp1.getInputStream(), new File(path));
				} catch (IOException e) {
					e.printStackTrace();
				} 
				shop.setDp1("/shops_images/"+fileName);
			}
			if(!filedp2.getOriginalFilename().equals("")){
				//详情图2
				String fileName = new Date().getTime()+filedp2.getOriginalFilename().substring(filedp2.getOriginalFilename().lastIndexOf("."));
				
				String path = req.getServletContext().getRealPath("//shops_images")+"/"+fileName;
				//System.out.println(path);
				try {
					FileUtils.copyInputStreamToFile(filedp2.getInputStream(), new File(path));
				} catch (IOException e) {
					e.printStackTrace();
				} 
				shop.setDp2("/shops_images/"+fileName);
			}
			if(!filedp3.getOriginalFilename().equals("")){
				//详情图3
				String fileName = new Date().getTime()+filedp3.getOriginalFilename().substring(filedp3.getOriginalFilename().lastIndexOf("."));
				
				String path = req.getServletContext().getRealPath("//shops_images")+"/"+fileName;
				//System.out.println(path);
				try {
					FileUtils.copyInputStreamToFile(filedp3.getInputStream(), new File(path));
				} catch (IOException e) {
					e.printStackTrace();
				} 
				shop.setDp3("/shops_images/"+fileName);
			}
	        //其他要修改的属性
	         if(req.getParameter("id")!=null&&!req.getParameter("id").equals("")){
	        	shop.setId(Integer.parseInt(req.getParameter("id")));
	        	
	         }
	         if(req.getParameter("clc")!=null&&!req.getParameter("clc").equals("")){
		        	shop.setClc(req.getParameter("clc"));
		        	
		         }
	         if(req.getParameter("cname")!=null&&!req.getParameter("cname").equals("")){
	        	 shop.setCname(req.getParameter("cname"));
		        	
		         }
	         if(req.getParameter("cstock")!=null&&!req.getParameter("cstock").equals("")){
		        	shop.setCstock(Integer.parseInt(req.getParameter("cstock")));
		        	
		         }
	         if(req.getParameter("city")!=null&&!req.getParameter("city").equals("")){
		        	shop.setCity(req.getParameter("city"));
		        	
		         }
	         if(req.getParameter("tel")!=null&&!req.getParameter("tel").equals("")){
		        	shop.setTel(req.getParameter("tel"));
		        	
		         }
	         if(req.getParameter("bd")!=null&&!req.getParameter("bd").equals("")){
		        	shop.setBd(req.getParameter("bd"));
		        	
		         }
	         if(req.getParameter("dn")!=null&&!req.getParameter("dn").equals("")){
		        	shop.setDn(req.getParameter("dn"));
		        	
		         }
	         if(req.getParameter("cprice")!=null&&!req.getParameter("cprice").equals("")){
		        	shop.setCprice(Double.parseDouble(req.getParameter("cprice")));
		        	
		         }
	    System.out.println(shop);
	    //商品更新到数据库
	    int index=shopServiceImpl.updataShop(shop);
	    return "/servlet/getAllShops";
	}
	//插入商品到数据库
	@RequestMapping("/servlet/insertShop")
	public String insertShop(HttpServletRequest req,HttpServletResponse resp,MultipartFile filecp,MultipartFile filedp1,MultipartFile filedp2,MultipartFile filedp3) throws UnsupportedEncodingException{
		
		HttpSession session = req.getSession();
		//新建shop，将下列属性付给shop，再插入到数据库
		Shop shop = new Shop();
		if(!filecp.getOriginalFilename().equals("")){
			String fileName = new Date().getTime()+filecp.getOriginalFilename().substring(filecp.getOriginalFilename().lastIndexOf("."));
			
			String path = req.getServletContext().getRealPath("//shops_images")+"/"+fileName;
			//System.out.println(path);
			try {
				FileUtils.copyInputStreamToFile(filecp.getInputStream(), new File(path));
			} catch (IOException e) {
				e.printStackTrace();
			} 
			shop.setCp("/shops_images/"+fileName);
		}
		if(!filedp1.getOriginalFilename().equals("")){
			String fileName = new Date().getTime()+filedp1.getOriginalFilename().substring(filedp1.getOriginalFilename().lastIndexOf("."));
			
			String path = req.getServletContext().getRealPath("//shops_images")+"/"+fileName;
			//System.out.println(path);
			try {
				FileUtils.copyInputStreamToFile(filedp1.getInputStream(), new File(path));
			} catch (IOException e) {
				e.printStackTrace();
			} 
			shop.setDp1("/shops_images/"+fileName);
		}
		if(!filedp2.getOriginalFilename().equals("")){
			String fileName = new Date().getTime()+filedp2.getOriginalFilename().substring(filedp2.getOriginalFilename().lastIndexOf("."));
			
			String path = req.getServletContext().getRealPath("//shops_images")+"/"+fileName;
			//System.out.println(path);
			try {
				FileUtils.copyInputStreamToFile(filedp2.getInputStream(), new File(path));
			} catch (IOException e) {
				e.printStackTrace();
			} 
			shop.setDp2("/shops_images/"+fileName);
		}
		if(!filedp3.getOriginalFilename().equals("")){
			String fileName = new Date().getTime()+filedp3.getOriginalFilename().substring(filedp3.getOriginalFilename().lastIndexOf("."));
			
			String path = req.getServletContext().getRealPath("//shops_images")+"/"+fileName;
			//System.out.println(path);
			try {
				FileUtils.copyInputStreamToFile(filedp3.getInputStream(), new File(path));
			} catch (IOException e) {
				e.printStackTrace();
			} 
			shop.setDp3("/shops_images/"+fileName);
		}
        
         if(req.getParameter("clc")!=null&&!req.getParameter("clc").equals("")){
	        	shop.setClc(req.getParameter("clc"));
	        	
	         }
         if(req.getParameter("city")!=null&&!req.getParameter("city").equals("")){
	        	shop.setCity(req.getParameter("city"));
	        	
	         }
         if(req.getParameter("cname")!=null&&!req.getParameter("cname").equals("")){
        	 shop.setCname(req.getParameter("cname"));
	        	
	         }
         if(req.getParameter("cstock")!=null&&!req.getParameter("cstock").equals("")){
	        	shop.setCstock(Integer.parseInt(req.getParameter("cstock")));
	        	
	         }
         if(req.getParameter("tel")!=null&&!req.getParameter("tel").equals("")){
	        	shop.setTel(req.getParameter("tel"));
	        	
	         }
         if(req.getParameter("bd")!=null&&!req.getParameter("bd").equals("")){
	        	shop.setBd(req.getParameter("bd"));
	        	
	         }
         if(req.getParameter("dn")!=null&&!req.getParameter("dn").equals("")){
	        	shop.setDn(req.getParameter("dn"));
	        	
	         }
         if(req.getParameter("cprice")!=null&&!req.getParameter("cprice").equals("")){
	        	shop.setCprice(Double.parseDouble(req.getParameter("cprice")));
	        	
	         }
    System.out.println(shop);
    //商品插入数据库
    int index=shopServiceImpl.insertShop(shop);
    return "redirect:/servlet/getAllShops";
    }
}

