package cn.zds.pojo;

public class Shop {
	private int id;
	private String clc;
//	clc分类
	//所属城市
	private String city;
	public String getCity() {
		return city;
	}
	@Override
	public String toString() {
		return "Shop [id=" + id + ", clc=" + clc + ", city=" + city + ", bd=" + bd + ", cp=" + cp + ", dp1=" + dp1
				+ ", dp2=" + dp2 + ", dp3=" + dp3 + ", dn=" + dn + ", tel=" + tel + ", doh=" + doh + ", cprice="
				+ cprice + ", cstock=" + cstock + ", cname=" + cname + "]";
	}
	public String getClc() {
		return clc;
	}
	public void setClc(String clc) {
		this.clc = clc;
	}
	public Double getCprice() {
		return cprice;
	}
	public void setCprice(Double cprice) {
		this.cprice = cprice;
	}
	public int getCstock() {
		return cstock;
	}
	public void setCstock(int cstock) {
		this.cstock = cstock;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setCity(String city) {
		this.city = city;
	}
	private String bd;
//	表示对商品的短暂描述
	private String cp;
//	表示封面图路径
	private String dp1;
//	表示详情图1路径
	private String dp2;
//	表示详情图2路径
	private String dp3;
//	表示详情图3路径
	private String dn;
//	表示详细描述
	private String tel;
//	商家电话
	private int doh;
	//热度
public String getBd() {
		return bd;
	}
	public void setBd(String bd) {
		this.bd = bd;
	}
	public String getCp() {
		return cp;
	}
	public void setCp(String cp) {
		this.cp = cp;
	}
	public String getDp1() {
		return dp1;
	}
	public void setDp1(String dp1) {
		this.dp1 = dp1;
	}
	public String getDp2() {
		return dp2;
	}
	public void setDp2(String dp2) {
		this.dp2 = dp2;
	}
	public String getDp3() {
		return dp3;
	}
	public void setDp3(String dp3) {
		this.dp3 = dp3;
	}
	public String getDn() {
		return dn;
	}
	public void setDn(String dn) {
		this.dn = dn;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public int getDoh() {
		return doh;
	}
	public void setDoh(int doh) {
		this.doh = doh;
	}
	//	dohΪ����Ʒ�ȶ�;
	private Double  cprice;
//	价格
	private int cstock;
//	库存
	private String cname;
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getId() {
		return id;
	}
	
}
