package cn.zds.controller;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;

import java.util.List;



import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.annotation.Resource;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;

import cn.zds.mapper.UserMapper;
import cn.zds.pojo.Order;
import cn.zds.pojo.Shop;
import cn.zds.pojo.User;
import cn.zds.service.OrderService;
import cn.zds.service.ShopService;
import cn.zds.service.UserService;



@Controller
public class UserController  {
	@Resource
	private UserService userServiceImpl;
	@Resource
	private ShopService shopServiceImpl;
	@Resource 
	private OrderService orderServiceImpl;
	//更新个人信息
	@RequestMapping("/servlet/userServlet")
	public String uploadUser(HttpServletRequest req,HttpServletResponse resp,MultipartFile file) throws UnsupportedEncodingException{
		//更新个人信息
			HttpSession session = req.getSession();
			User u = (User) session.getAttribute("user");
			if(!file.getOriginalFilename().equals("")){
				String fileName = new Date().getTime()+file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
				
				String path = req.getServletContext().getRealPath("//user_images")+"/"+fileName;
				//System.out.println(path);
				try {
					//图片文件写入
					FileUtils.copyInputStreamToFile(file.getInputStream(), new File(path));
				} catch (IOException e) {
					e.printStackTrace();
				} //用户属性更新
				u.setHp("/user_images/"+fileName);
			}
			
			
	        
	         if(req.getParameter("address")!=null&&!req.getParameter("address").equals("")){
	        	String address=new  String(((String) req.getParameter("address")).getBytes("iso-8859-1"),"utf-8");
	        	//用户地址更新
	        	 u.setAddress(address);//���õ�ַ
	        	
	         }
	       
	         if(req.getParameter("tel")!=null&&!req.getParameter("tel").equals("")){
	        	//用户电话更新
	        	 u.setTel((String) req.getParameter("tel"));
	        	 
	         }
	         if(req.getParameter("password")!=null&&!req.getParameter("password").equals("")){
	        	//用户密码更新
	        	 u.setPassword((String) req.getParameter("password"));
	        	
	         }
	       //将用户更新自数据库
	        int up_index=   userServiceImpl.updateUser(u); 
	         if(up_index>0){
	        	 req.setAttribute( "msg","个人信息更新成功");
	        	 return "forward:/myselfcontroal.jsp";
	             
	         }
	         else {	
	        	 req.setAttribute( "msg","个人信息更新失败");
			          return "/myselfcontroal.jsp";
				}
	}
	
	
	@RequestMapping("/servlet/loginservlet")
	public String loginservlet(HttpServletRequest req,HttpServletResponse resp){
		String bath = req.getContextPath();
		HttpSession hs = req.getSession();
		User user = new User();
		if (req.getParameter("oper").equals("login")) {//������Ϊlogin
			try {
				return Login(req, resp);//登录方法
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if (req.getParameter("oper").equals("out")) {//登出

			hs.invalidate();// session注销
			
			return "redirect:/Login.jsp";
			
		} else if (req.getParameter("oper").equals("read")) {//查看个人信息

			String id = req.getParameter("shopname");
			Shop shop = shopServiceImpl.selCdByIdShop(id);
			req.setAttribute("shop2", shop);
			return "/cd.jsp";

		} else if (req.getParameter("oper").equals("shop_cat")) {//个人购物车ﳵ

			User olduser = (User) hs.getAttribute("user");
			//查询普通用户
			User newuser = userServiceImpl.selChickUser(olduser.getUname(), olduser.getPassword());// ���ݻỰ��user��uid
			if(newuser==null)	{
				//普通用户不存在，去超级用户找
				newuser=userServiceImpl.selSupUser(olduser.getUname(), olduser.getPassword());
			}
			hs.setAttribute("user", newuser);
			
			String commodity = newuser.getCommodity()==null?"":newuser.getCommodity();// �õ�user�е���Ʒ
			String[] commoditys = commodity.split(";");//将商品idyong；分割

			List<Shop> shopList = new ArrayList<Shop>();
			for (String id : commoditys) {

				Shop shop = shopServiceImpl.selCdByIdShop(id);// 通过商品id查找详细商品信息
				shopList.add(shop);//添加到shoplist
			}
			req.setAttribute("shoplist", shopList);//shoplist放入session
			return "/shop_cat.jsp";
		} else if (req.getParameter("oper").equals("insert_into_commidity")) {//将商品id插入用户ﳵ
			user = (User) hs.getAttribute("user");
			String shop_id = (String) req.getParameter("shop_id");// 拿到商品id

			if (!(user.getCommodity() == null || user.getCommodity().equals(""))) {
				user.setCommodity(user.getCommodity() + ";" + shop_id);// 将商品id更新到用户
			} else {
				user.setCommodity(shop_id);
			}
			
			int index = userServiceImpl.updateUser(user);// 用户更新自数据库
			// System.out.println(index);
			
			return "redirect:/servlet/loginservlet?oper=shop_cat";
		} else if (req.getParameter("oper").equals("del_shop")) {//删除用户中的商品
			user = (User) hs.getAttribute("user");
			String commodity = user.getCommodity();
			String[] commoditys = commodity.split(";");// 将用户商品以；分割放入数组
			commodity = "";
			Boolean flag = false;//找到的标志，避免多删除商品
			for (int i = 0; i < commoditys.length; i++) {

				if (!commoditys[i].equals(req.getParameter("shop_id"))) {
					//如果商品id不为要删除的，就将商品id还原到用户上
					commodity = commodity + ";" + commoditys[i];

				} else {
					if (flag) {//删过了，其他的加到用户商品上去
						commodity = commodity + ";" + commoditys[i];
					}
					//这里的删除指的是不把商品id加到用户商品上去
					flag = true;
				}

			}
		
			user.setCommodity(commodity);// 用户更新商品列
			int index = userServiceImpl.updateUser(user);//用户更新自数据库
			
			return "redirect:/servlet/loginservlet?oper=shop_cat";//跳转购物车
		} else if (req.getParameter("oper").equals("register")) {
			// 注册
			int index=0;
			User u_register = new User();
			if(req.getSession().getAttribute("qqUser")!=null){
				//获取通过qq登录注册的用户
				User qqUser=(User) req.getSession().getAttribute("qqUser");
				//通过用户名密码去查找普通用户
				User ckUser=userServiceImpl.selChickUser(qqUser.getUname(), qqUser.getPassword());
				if(ckUser==null){//如果没有找到
					//将qq登录的用户给注册user
					u_register=qqUser;
					//设置默认头像
					u_register.setHp("img/a1.jpg");
					//插入普通用户表
					 index = userServiceImpl.insertUser(u_register);
				}else {
					//存在的话把qq登录用户给注册user
					u_register=qqUser;
					//返回值为1
					index=1;
				}
				
			}
			else {
				//非qq登录。正常注册
				u_register.setUname(req.getParameter("uname"));
				u_register.setTel(req.getParameter("tel"));
				u_register.setHp("img/a1.jpg");
				u_register.setPassword(req.getParameter("password"));
				 index = userServiceImpl.insertUser(u_register);
			}
			
			
			
			User u = userServiceImpl.selChickUser(u_register.getUname(), u_register.getPassword());
			if (index > 0) {//标志大于0
				
				hs.setAttribute("user", u);
				//设置cookie
				Cookie cookie = new Cookie("uid", u.getId() + "");
				cookie.setMaxAge(3 * 24 * 3600);
				cookie.setPath("ck");
				resp.addCookie(cookie);
				return "redirect:/servlet/main";
			}
		}

		else {
			return "/Login.jsp" ;
		}
		return "/Login.jsp";
	}

	private String Login(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		String uname = req.getParameter("uname");
		String password = req.getParameter("pwd");
		//去普通表查找用户
		User u = userServiceImpl.selChickUser(uname, password);
		
		if (u != null) {//查到了，用户为普通用户
			System.out.println("我是普通用户");
			List<Order> os = orderServiceImpl.selGetOrderbyName(u.getUname());
			req.getSession().setAttribute("order", os);// 把通过用户名找到的订单拿到
			Cookie cookie = new Cookie("uid", u.getId() + "");
			cookie.setMaxAge(3 * 24 * 3600);
			cookie.setPath("ck");
			resp.addCookie(cookie);

			HttpSession hs = req.getSession();
			hs.setAttribute("user", u);
			req.setAttribute("erro", null);
			return "forward:/servlet/main";
		
		} else {
			System.out.println("我是超级用户");
			//去超级用户查
			User superUser=userServiceImpl.selSupUser(uname, password);
			if(superUser!=null){
				

				HttpSession hs = req.getSession();
				hs.setAttribute("user", superUser);
				hs.setAttribute("SuperPower", superUser);
				return "forward:/servlet/main";
			}
			else {
				req.setAttribute("erro", "用户名或密码错误");
				return "/Login.jsp";
				// ����return
			}
			

		}

		
	}
	
	@RequestMapping("/servlet/ck")
	private String ck(HttpServletRequest req,HttpServletResponse resp){
		String bath = req.getContextPath();
		Cookie[] cookies = req.getCookies();
		if (cookies != null) {
			String uid = "";
			for (Cookie cookie : cookies) {
				if ("uid".equals(cookie.getName())) {
					uid = cookie.getValue();
				}
			}

			if ("".equals(uid)) {
				
				return "/Login.jsp";
			} else {
				User u = userServiceImpl.selChickUid(uid);
				if (u != null) {
					//通过用户名查订单
					List<Order> os = orderServiceImpl.selGetOrderbyName(u.getUname());
					req.getSession().setAttribute("order", os);// 订单放到个人订单表
					ServletContext sc = req.getServletContext();
					req.getSession().setAttribute("user", u);
					return "redirect:main";
				} else {
					
					return "/Login.jsp";
				}
			}
		} else {
			
			return "/Login.jsp";
		}

	}
	@RequestMapping("/servlet/updataUser")
	@ResponseBody
	public void updataUser(HttpServletRequest req,HttpServletResponse resp){
		//ajax方式
		
			Gson gson = new Gson();
			//获取传来的user
		    Object res = gson.fromJson(req.getParameter("user"), User.class);
		    User user=new User();
		    user=(User) res;
		   //更新自数据库
		    userServiceImpl.updateUserBySuper(user);
 	}
	@RequestMapping("/servlet/getUsers")
	
	public String getAllUsers(HttpServletRequest req,HttpServletResponse resp){
		//拿到所有用户，超级用户使用
			List<User> users=userServiceImpl.selAllUsers();
			req.setAttribute("users", users);
			return "/super/user.jsp";
 	}
	
	@RequestMapping("/servlet/delUser")
	@ResponseBody
	public void delUser(HttpServletRequest req,HttpServletResponse resp){
		//ajax方式
		
		 Gson gson = new Gson();
		    Object res = gson.fromJson(req.getParameter("user"), User.class);
		    User user=new User();
		    user=(User) res;
		    System.out.println(user);
		    //删除用户自数据库
		    int index = userServiceImpl.delUser(user);
		 
 	}
	
	@RequestMapping("/servlet/userSerach")
	public String getOrdersBySerach(HttpServletRequest req,HttpServletResponse resp){
		//通过模糊搜索用户
	
			
			String uname=req.getParameter("userSerach")+"";//防止为空
			System.out.println(req.getParameter("orderSerach")+"");
			req.setAttribute("users", userServiceImpl.selAllUsersBySerach(uname));
		

        
		return "/super/user.jsp";
		
	}
}
