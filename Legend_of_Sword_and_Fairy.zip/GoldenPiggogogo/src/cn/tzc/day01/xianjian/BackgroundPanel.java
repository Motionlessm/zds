package cn.tzc.day01.xianjian;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;



import cn.tzc.day01.xianjian.*;


public class BackgroundPanel extends JPanel{
	
	Image ljcImage;
	int LJCx, LJCy;               //��Ҵ�ͼƬ������
	

	Image ljcAWS;
	int LJCawsx, LJCawsy;         //����ɩͼƬ������
	
	Image ljcWCS;
	int LJCwcsx, LJCwcsy;		  //����ɩͼƬ������
	
	Image ljcXIAOJI;
	int LJCxjx, LJCxjy;			  //С��ͼƬ����Ƭ
	
	
	
	
	// ���췽�� ������ʼ��
	public BackgroundPanel() 
	{
		try {
			ljcImage = ImageIO.read(new File("ImageGalley/LiJiaCun/0.png"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		LJCx = -200;
		LJCy = -200;
		
		try {
			ljcAWS =ImageIO.read(new File("ImageGalley/AWangSao/0.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			ljcWCS =ImageIO.read(new File("ImageGalley/WangCaiSao/0.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			ljcXIAOJI =ImageIO.read(new File("ImageGalley/XiaoJi/0.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	
	}
	
	
	public void Paint(Graphics g)
	{
		g.drawImage(Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("lbxx.png")),
						-200,-200,this);
		//g.drawImage((Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("1.png")),
		//				-200,-200,this);
		
		/*
		 * ����ͼƬ
		 */
		
		
	}
	
}


/*package cn.tzc.day01.xianjian;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

//java��ѭ���̳У��ࣩ��ʵ�֣��ӿڣ�
public class GamePanel extends JPanel implements Runnable,KeyListener{

	
	Image img_LJCcontent;
	int LJCx, LJCy;               //��Ҵ�ͼƬ������
	
	Image[] img_AWS;
	int AWSx, AWSy, AWSindex;    //������ͼƬ�����ꡢ�±�
	
	Image[] img_WCS;
	int WCSx, WCSy, WCSindex;    //����ɩͼƬ�����ꡢ�±�
	
	Image[] img_AZ;
	int AZx, AZy, AZindex;       //����ͼƬ�����ꡢ�±�
	
	Image[] img_XH;
	int XHx, XHy, XHindex;       //С��ͼƬ�����ꡢ�±�
	
	Image[] img_XJ;
	int XJx, XJy, XJindex;       //С��ͼƬ�����ꡢ�±�
	
	Image[] img_MJ;
	int MJx, MJy, MJindex;       //ĸ��ͼƬ�����ꡢ�±�
	
	Image[] img_XXJ;
	int XXJx, XXJy, XXJindex;       //С��ͼƬ�����ꡢ�±�
	
	
	//����ң
	Image[] img_LXYup;              
	Image[] img_LXYdown;
	Image[] img_LXYleft;
	Image[] img_LXYright;
	Image img_LXYcontent;      //����ң��ǰͼƬ
	int LXYx, LXYy, LXYindex, LXYdir; /*����ң�����ʾ��1��2��3��4��������
	
	//����
	Image img_Chat;         			//����ͼƬ
	int Chatx, Chaty;       			//��������
	String[] ChatMessages;              //��������
	boolean isChatShow;                 //�����Ƿ���ʾ
	int ChatMessageindex;               //������ʾ���칦�ܵ���������Ƿ���ֵ�״ֵ̬
	
	//�����ϰ��﹦�����������
	BufferedImage LJCDateMap;
	int MapId;
	
	
	//��ʼ���������������
	//������Ҵ��̳�-
		Image[] ljcscImage;;
		int ljcscX;
		int ljcscY;
		int ljcscIndex;
		BufferedImage ljcscDataMap;
			//�����
			Image img_LiKai;
			 Image img_JZ;
			 int JZx;
			 int JZy;
			 boolean Taskbox;
			 String renwu0;
			 String renwu1;
			 String renwu2;
			 String renwu3;
			 String renwu4;
			 String renwu5;
			 String renwu6;
			 String renwu7;
	//�����ͷ
		 Image[] hereImages;
		 int hereImageIndex;
		 //״̬��
		 Image ztlImage;
		 int ztlX;
		 int ztlY;
		 boolean ztlchuxian;
		 //������Ʒ
		 Image wplImage;
		 int wplX;
		 int wplY;
		 Image byImage;
		 Image hbImage;
		 boolean wplchuxian;
		//����ʮ���³���
		Image slpImage;
		int slpX;
		int slpY;
		BufferedImage slpDatamap;
		//��������ң��ֳ���
		Image bjImage;
		Image lxydgImage;
		Image gwImage;
		int lxydqsm;
		int lxyzsm;
		int gwdqsm;
		int gwzsm;
		int lxygjl;
		int gwgjl;
		int lxydj;
		int cg;
		int dl;
		int wpqr;
		int[] wp;
		int wpqs;
		int wpcx;
		int lxydqll;
	    int lxyzll;
	    int llbg;
	    int lxydqjy;
	    int lxyzjy;
	    int lxysj;
	    int lxyflz;
	    int lxyfyl;
	    Image cgImage;
	    Image dlImage;
	    Image sjImage;
	    Image yrImage;
	    Image llbz;
	    int yrdqsm;
	    int yrzsm;
	    int yrgjl;
		//����Ƭͷ
	    Image[] ptImages;
	    int ptIndex;
	    Image begin;
	    Image jwImage;
	    Image ydlImage;
	    Image yrdlImage;
	    Image yqImage;
	
	public GamePanel() {
		//��ʼ����Ҵ�ͼƬ���������
		try {
			img_LJCcontent =ImageIO.read(new File("ImageGalley/LiJiaCun/0.png"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		LJCx = -200;
		LJCy = -200;
		
		//��ʼ��������
		img_AWS = new Image[17];
		for(int i=0; i<img_AWS.length; i++) {
			try {
				img_AWS[i] =ImageIO.read(new File("ImageGalley/AWangSao/"+i+".png"));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		AWSx = 600;
		AWSy = 600;
		AWSindex = 0;
		
		//��ʼ������ɩ
		img_WCS = new Image[14];
		for(int i=0; i<img_WCS.length; i++) {
			try {
				img_WCS[i] =ImageIO.read(new File("ImageGalley/WangCaiSao/"+i+".png"));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		WCSx = 779;
		WCSy = 510;
		WCSindex = 0;
		
		//��ʼ������
		img_AZ = new Image[6];
		for(int i=0; i<img_AZ.length; i++) {
			try {
				img_AZ[i] =ImageIO.read(new File("ImageGalley/AZhu/"+i+".png"));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		AZx = 515;
		AZy = 510;
		AZindex = 0;
		
		//��ʼ��С��
		img_XH = new Image[4];
		for(int i=0; i<img_XH.length; i++) {
			try {
				img_XH[i] =ImageIO.read(new File("ImageGalley/XiaoHai/"+i+".png"));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		XHx = 900;
		XHy = 600;
		XHindex = 0;
		
		//��ʼ��ĸ��
		img_MJ = new Image[6];
		for(int i=0; i<img_MJ.length; i++) {
			try {
				img_MJ[i] =ImageIO.read(new File("ImageGalley/MuJi/"+i+".png"));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		MJx = 530;
		MJy = 580;
		MJindex = 0;
		
		//��ʼ��С��
		img_XJ = new Image[2];
		for(int i=0; i<img_XJ.length; i++) {
			try {
				img_XJ[i] =ImageIO.read(new File("ImageGalley/XiaoJi/"+i+".png"));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		XJx = 500;
		XJy = 590;
		XJindex = 0;
		
		//��ʼ��СС��
		img_XXJ = new Image[2];
		for(int i=0; i<img_XXJ.length; i++) {
			try {
				img_XXJ[i] =ImageIO.read(new File("ImageGalley/XiaoXiaoJi/"+i+".png"));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		XXJx = 500;
		XXJy = 570;
		XXJindex = 0;
		
		//��ʼ������ң
		img_LXYup = new Image[8];
		img_LXYdown = new Image[8];
		img_LXYleft = new Image[8];
		img_LXYright = new Image[8];
		for(int i=0; i<img_LXYup.length; i++) {
			try {
				img_LXYup[i] =ImageIO.read(new File("ImageGalley/LiXiaoYao_Up/"+i+".png"));
				
				img_LXYdown[i] =ImageIO.read(new File("ImageGalley/LiXiaoYao_Down/"+i+".png"));
				
				img_LXYleft[i] =ImageIO.read(new File("ImageGalley/LiXiaoYao_Left/"+i+".png"));
				
				img_LXYright[i] =ImageIO.read(new File("ImageGalley/LiXiaoYao_Right/"+i+".png"));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		LXYx = 650;
		LXYy = 590;
		LXYindex = 0;
		LXYdir = KeyEvent.VK_DOWN;
		img_LXYcontent = img_LXYdown[LXYindex];
		
		//��ʼ����������
		try {
			img_Chat =ImageIO.read(new File("ImageGalley/LiaoTian/0.png"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		ChatMessages = new String[]{"Hello!", "Hi!", "How are you!", "I'm fine", "Thank you", "rua~~!!"};
		ChatMessageindex = 0;
		isChatShow = false;
		
		
		//��ʼ���������������
		 //��������ʼ
		 try {
			img_JZ = ImageIO.read(new File("ImageGalley/RenWu/juanzhou.png"));
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		 JZx=800;
		 JZy=50;
		 try {
				img_LiKai = ImageIO.read(new File("ImageGalley/RenWu/likai.png"));
			} catch (IOException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}
		 renwu1 = new String("�Ұ�����");
		 renwu2 = new String("������ɩ");
		 renwu3 = new String("�� �� ��");
		 renwu4 = new String("�� �� ��");
		 renwu5 = new String("�ռ�����");
		 renwu6 = new String("��ȥ�Ұ�����");
		 renwu7 = new String("�������");
		 //��ʼ����ͷ
		 hereImages = new Image[10];
		 for(int i=0;i<hereImages.length;i++){
			 try {
				hereImages[i] = ImageIO.read(new File("ImageGalley/here/"+i+".png"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		//״̬����ʼ
		 try {
			ztlImage = ImageIO.read(new File("ImageGalley/RenWu/ztl.png"));
		} catch (IOException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		 ztlX=10;
		 ztlY=10;
		 ztlchuxian = false;

		lxyfyl=10;
		lxyflz=100;
		//��Ʒ����ʼ
		 try {
			wplImage = ImageIO.read(new File("ImageGalley/RenWu/wpl.png"));
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		 wplX = 290;
		 wplY = 685;
		 wplchuxian = false;
		 try {
				byImage = ImageIO.read(new File("ImageGalley/RenWu/by.png"));
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		 try {
				hbImage = ImageIO.read(new File("ImageGalley/RenWu/hb.png"));
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}

		//��ʼ���ϰ��﹦��������������
		try {
			LJCDateMap = ImageIO.read(new File("ImageGalley/LiJiaCun/RedMap.png"));
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		MapId=0;
		ljcscImage = new Image[3];
		for(int i=0;i<2;i++)
		{
				try {
					ljcscImage[i] = ImageIO.read(new File("ImageGalley/LiJiaCunShiChang/"+i+".png"));
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
		}
		ljcscX=200;
		ljcscY=200;
		ljcscIndex=0;
		//��ʼ���ϰ��﹦��������������
			try {
				ljcscDataMap = ImageIO.read(new File("ImageGalley/LiJiaCunShiChang/RedMap.png"));
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		//��ʼ��ʮ����
			try {
				slpImage = ImageIO.read(new File("ImageGalley/ShiLiPo/0.png"));
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			slpX=100;
			slpY=100;
			try {
				slpDatamap = ImageIO.read(new File("ImageGalley/ShiLiPo/RedMap.jpg"));
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		//��ʼ��ս������
			try {
				bjImage = ImageIO.read(new File("ImageGalley/DaGuai/BaiJing.jpg"));
				gwImage = ImageIO.read(new File("ImageGalley/DaGuai/guaiwu.png"));
				lxydgImage = ImageIO.read(new File("ImageGalley/DaGuai/LiXiaoYaoDaGuai.png"));
				cgImage = ImageIO.read(new File("ImageGalley/DaGuai/shengli.png"));
				dlImage = ImageIO.read(new File("ImageGalley/DaGuai/huodehuaban.png"));
				sjImage = ImageIO.read(new File("ImageGalley/DaGuai/shengjila.png"));
				yrImage = ImageIO.read(new File("ImageGalley/DaGuai/yuren.png"));
				ydlImage = ImageIO.read(new File("ImageGalley/DaGuai/yurou.png"));
				yrdlImage =ImageIO.read(new File("ImageGalley/DaGuai/yurou0.jpg"));
				llbz = ImageIO.read(new File("ImageGalley/DaGuai/linglibuzu.png"));
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			lxydqsm=100;  
			lxyzsm=100;
			gwdqsm=50;
			gwzsm=50;
			lxygjl=10;
			gwgjl=5;
			lxydj=1;
			cg=0;
			dl=0;
			wp=new int[]{0,0,0,0,0,0,0,0,0,0,0};
			wpqs=0;
			wpcx=0;
			lxydqll=100;
			lxyzll=100;
			llbg=0;
			lxydj=1;
			lxydqjy=0;
			lxyzjy=50;
			lxysj=0;
			yrdqsm=150;
			yrzsm=150;
			yrgjl=15;
			//Ƭͷ
			ptImages = new Image[60];
			for(int i=0;i<60;i++){
				try {
					ptImages[i] = ImageIO.read(new File("ImageGalley/PianTou/"+i+".png"));
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
			try {
				begin = ImageIO.read(new File("ImageGalley/PianTou/begin.png"));
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			//��β
			try {
				jwImage = ImageIO.read(new File("ImageGalley/PianTou/jeiwei.png"));
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			try {
				yqImage = ImageIO.read(new File("ImageGalley/LiJiaCun/yuanqu.png"));
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		
	}
	
	public void paint(Graphics g) {
		g.drawImage(Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("0.png")),
				-200,-200,this);
		
		g.drawImage(
				Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("azhu0.png")),
						315,310,this);//����ͼƬ����
		
		g.drawImage(
				Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("awangshen0.png")),
						480,310,this);//������ͼƬ����
		
		g.drawImage(
				Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("wangcaisao0.png")),
						579,310,this);//����ɩͼƬ����
	
		g.drawImage(
				Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("xiaohai0.png")),
						700,400,this);//С��ͼƬ����
		
		g.drawImage(
				Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("muji0.png")),
						330,380,this);//ĸ��ͼƬ����
		
		g.drawImage(
				Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("xiaoji0.png")),
						300,390,this);//С��ͼƬ����
		
		g.drawImage(
				Toolkit.getDefaultToolkit().getImage(BackgroundPanel.class.getResource("xiaoxiaoji0.png")),
						300,370,this);//СС��ͼƬ����
		
		
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		//System.out.println("���̰������ɿ�!");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
*/