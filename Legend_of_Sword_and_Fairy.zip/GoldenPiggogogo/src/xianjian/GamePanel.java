package xianjian;

import java.awt.Graphics;
import java.awt.Toolkit;

import javax.swing.JPanel;

/**
 * �����ʾ��Ϸ��Ŀ���Զ��廭���࣬Ҳ���ǽ���
 * @author MyPC
 *
 */
public class GamePanel extends JPanel{
	//�滭����
	public void paint(Graphics g){
		//g-->�����һ֧����
		//��ǰ׼�����������ļ���ͼƬ�ļ������ͬһ��·����
		//g.drawImage(ͼƬ����, 0,0,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/LiJiaCun/0.png")),-200,-200,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/AWangShen/0.png")),450,310,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/AZhu/0.png")),600,70,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/AZhu/0.png")),110,690,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/AZhu/0.png")),110,690,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/AZhu/0.png")),110,690,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/AZhu/0.png")),110,690,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/MuJi/0.png")),530,100,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/WangCaiSao/0.png")),490,400,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/XiaoJi/0.png")),500,160,this);
		g.drawImage(Toolkit.getDefaultToolkit().getImage(GamePanel.class.getResource("Legend_of_Sword_and_Fairy/XiaoXiaoJi/0.png")),500,130,this);
	}

}
