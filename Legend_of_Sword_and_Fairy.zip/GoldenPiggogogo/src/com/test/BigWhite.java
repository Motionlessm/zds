package com.test;

import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

import javax.swing.JFrame;

public class BigWhite extends JFrame {
	public BigWhite() {
		super();
		initialize();// ���ó�ʼ������
	}

	private void initialize() {// ��ʼ������
		this.setSize(600, 800);// ���ô����С
		setDefaultCloseOperation(EXIT_ON_CLOSE);/// ���ô���رշ�ʽ
		this.setTitle("���Ƽ���ͼ��");// ���ô������
		MyCanvas c = new MyCanvas();// ������������
		add(c);// ���������ӵ�������
	}

	public static void main(String[] args) {
		new BigWhite().setVisible(true);// ���ô���ɼ�

	}

	private class MyCanvas extends Canvas {// �����ڲ���MyCanvas�̳�Canvas
		@Override
		public void paint(Graphics g) {
			Graphics2D g2 = (Graphics2D) g;// �����»�ͼ��Graphics2D��ǿ��ת��ΪGraphics2D����ࣩ
			
			Stroke stroke =new BasicStroke(2.0f);
			
			//1 Black 2 �ո� 3 Gray
			
			//Head
			int [][]head = new int[8][17];
			for(int i=0;i<=16;i++) {
				if(i<=12&&i>=4)
					head[0][i]=1;
				else
					head[0][i]=2;
				if(i>=3&&i<=4 || i>=12&&i<=13)
					head[4][i] = 1;
				if(i>=3 && i<=13)
					head[5][i] = 1;
				if(i>=3&&i<=5 || i>=11&&i<=13)
					head[4][i] = 1;
			}
			head[1][0]=head[1][1]=head[1][15]=head[1][16]=head[2][0]=head[2][16]=2;
			head[1][2]=head[1][3]=head[1][13]=head[1][14]=head[2][1]=head[2][15]=head[7][0]=head[7][1]=head[7][15]=1;
			head[7][14]=3;
			for(int i=3;i<=6;i++) {
				head[i][0]=head[i][16]=1;
				head[i][15]=3;
			}
			head[7][16]=2;
			for(int i=0; i<8; i++) {
				for(int j=0;j<17;j++) {
					if(head[i][j] == 0)
					{
						g2.setColor(Color.white);
						g2.fillRect(152+16*j, 140+16*i, 16, 16);
					}
					else if(head[i][j] == 1)
					{
						g2.setColor(Color.black);
						g2.fillRect(152+16*j, 140+16*i, 16, 16);
					}
					else if(head[i][j] == 3)
					{
						g2.setColor(new Color(205,201,201));
						g2.fillRect(152+16*j, 140+16*i, 16, 16);
					}
				}
			}
			
			//Body
			int[][]body = new int[19][18];
			body[0][1]=body[0][2]=body[0][16]=body[0][11]=body[0][12]=body[0][13]=body[1][14]=body[1][15]=3;
			body[1][1]=body[2][1]=body[3][1]=body[4][1]=body[6][1]=body[7][1]=body[8][1]=body[7][17]=body[8][17]=body[9][17]=3;
			body[13][3]=body[13][4]=body[13][15]=body[13][14]=body[12][16]=3;
			for(int i=5;i<=13;i++) {
				body[14][i]=3;
				if(i>=5&&i<=7 || i>=11&&i<=13)
					body[17][i] = 3;
			}
			for(int i=1;i<=4;i++) {
				body[i][0] = 3;
			}
			body[11][0]=body[12][0]=body[12][1]=body[13][0]=body[13][1]=body[13][2]=2;
			for(int i=14;i<=18;i++) {
				for(int j=0;j<=4;j++) {
					body[i][j] = 2;
				}
				for(int j=15;j<=17;j++) {
					body[i][j] = 2;
				}
			}
			body[0][0]=body[0][3]=body[0][14]=body[0][15]=body[0][17]=body[15][9]=1;
			for(int i=1;i<=4;i++) {
				body[i][1]=1;
			}
			for(int i=1;i<=3;i++) {
				body[i][17]=1;
			}
			for(int i=4;i<=13;i++) {
				body[1][i]=1;
			}
			for(int i=12;i<=14;i++) {
				body[3][i]=1;
				body[5][i]=1;
				body[7][i]=1;
			}
			for(int i=4;i<=6;i++) {
				body[i][11]=1;
				body[i][15]=1;
			}
			for(int i=5;i<=11;i++) {
				body[i][0]=1;
			}
			body[12][1]=body[13][2]=body[14][3]=body[14][4]=body[12][17]=body[13][16]=body[13][17]=body[14][15]=body[14][14]=1;
			for(int i=15;i<=17;i++) {
				body[i][4]=1;
				body[i][8]=1;
				body[i][10]=1;
				body[i][14]=1;
			}
			for(int i=5;i<=7;i++) {
				body[18][i]=1;
			}
			for(int i=11;i<=13;i++) {
				body[18][i]=1;
			}
			body[18][10]=body[18][8]=body[18][9]=body[17][9]=body[16][9]=body[18][14]=2;
			for(int i=0; i<19; i++) {
				for(int j=0;j<18;j++) {
					if(body[i][j] == 0)
					{
						g2.setColor(Color.white);
						g2.fillRect(136+16*j, 268+16*i, 16, 16);
					}
					else if(body[i][j] == 1)
					{
						g2.setColor(Color.black);
						g2.fillRect(136+16*j, 268+16*i, 16, 16);
					}
					else if(body[i][j] == 3)
					{
						g2.setColor(new Color(205,201,201));
						g2.fillRect(136+16*j, 268+16*i, 16, 16);
					}
				}
			}
			
			//LeftHand
			int [][]lefthand = new int[10][7];
			for(int i=0;i<10;i++) {
				for(int j=0;j<2;j++) {
					lefthand[i][j]=1;
				}
			}
			lefthand[0][0]=lefthand[0][1]=lefthand[1][0]=lefthand[0][6]=lefthand[9][6]=lefthand[9][1]=lefthand[9][2]=lefthand[8][1]=2;
			for(int i=4;i<10;i++) {
				lefthand[i][0]=2;
			}
			for(int i=2;i<6;i++) {
				lefthand[0][i]=1;
			}
			for(int i=3;i<6;i++) {
				lefthand[9][i]=1;
			}
			for(int i=1;i<5;i++) {
				lefthand[i][6]=1;
			}
			lefthand[1][2]=lefthand[1][5]=lefthand[8][2]=lefthand[8][6]=1;
			lefthand[8][3]=lefthand[8][4]=lefthand[8][5]=lefthand[7][4]=lefthand[7][5]=3;
			for(int i=0; i<10; i++) {
				for(int j=0;j<7;j++) {
					if(lefthand[i][j] == 0)
					{
						g2.setColor(Color.white);
						g2.fillRect(24+16*j, 252+16*i, 16, 16);
					}
					else if(lefthand[i][j] == 1)
					{
						g2.setColor(Color.black);
						g2.fillRect(24+16*j, 252+16*i, 16, 16);
					}
					else if(lefthand[i][j] == 3)
					{
						g2.setColor(new Color(205,201,201));
						g2.fillRect(24+16*j, 252+16*i, 16, 16);
					}
				}
			}
			
			
			//RightHand
			int righthand[][] = new int[15][4];
			for(int i=0;i<3;i++) {
				for(int j=1;j<4;j++) {
					righthand[i][j]=2;
				}
			}
			righthand[3][3]=righthand[4][3]=righthand[14][2]=righthand[14][3]=righthand[13][3]=2;
			righthand[6][2]=righthand[7][2]=righthand[8][2]=3;
			righthand[0][0]=righthand[1][1]=righthand[2][1]=righthand[3][2]=righthand[4][2]=righthand[11][1]=righthand[12][1]=righthand[13][2]=righthand[13][0]=righthand[14][0]=righthand[14][1]=1;
			for(int i=3;i<=11;i++) {
				righthand[i][0]=1;
			}
			for(int i=5;i<=12;i++) {
				righthand[i][3]=1;
			}
			for(int i=0; i<15; i++) {
				for(int j=0;j<4;j++) {
					if(righthand[i][j] == 0)
					{
						g2.setColor(Color.white);
						g2.fillRect(424+16*j, 284+16*i, 16, 16);
					}
					else if(righthand[i][j] == 1)
					{
						g2.setColor(Color.black);
						g2.fillRect(424+16*j, 284+16*i, 16, 16);
					}
					else if(righthand[i][j] == 3)
					{
						g2.setColor(new Color(205,201,201));
						g2.fillRect(424+16*j, 284+16*i, 16, 16);
					}
				}
			}
			
			
//			g2.setColor(Color.black);
//			g2.fillRect(152, 136, 16, 16);
//			g2.setColor(new Color(205,201,201));
//			g2.drawOval(156, 140, 8, 8);
//			
//			g2.setColor(Color.black);
//			g2.fillRect(152, 136, 16, 16);
//			g2.setColor(new Color(205,201,201));
//			g2.drawOval(156, 140, 8, 8);
			
			
			
			/*Black Rect
			g2.setColor(Color.black);
			g2.fillRect(50+16, 50+16, 16, 16);
			g2.setColor(new Color(205,201,201));
			g2.drawOval(54+16, 54+16, 8, 8);
			*/
			
			
			/*//while Rect
			g2.setColor(Color.white);
			g2.fillRect(50+16, 50, 16, 16);
			g2.setColor(new Color(190,190,190));
			g2.setStroke(stroke);
			g2.drawOval(54+16, 54, 8, 8);
			*/
			
			/*//Gray Rect
			g2.setColor(new Color(205,201,201));
			g2.fillRect(50, 50, 16, 16);
			g2.setColor(new Color(139,139,131));
			g2.setStroke(stroke);
			g2.drawOval(54, 54, 8, 8);
			*/
			
			
			//g2.drawOval(50, 50, 100, 100);// ��һ��Բ��-���ꡢ���ߣ�Draw�������Ƶ�ͼ���ǿ��ĵģ�
			//g2.drawLine(80, 145, 70, 250);
			//g2.drawLine(115, 145, 120, 250);
			//g2.drawLine(80, 100, 48, 200);
			//g2.fillOval(110, 5, 100, 100);// ��һ��Բ�Σ�fill�������Ƶ�ͼ����ʵ�ĵģ�
			//g2.drawRect(220, 5, 90, 90);// ��һ������
			//g2.fillRect(320, 5, 90, 90);// ��һ�����Σ�����䣩

			//Shape shape1 = new Ellipse2D.Double(5, 110, 100, 100);
			//g2.draw(shape1);// ������
			//g2.drawArc(110, 110, 1000, 1000, 170, 180);// �����Σ����Σ�
			//g2.fillArc(220, 110, 100, 100, 220, 200);// �����Σ����Σ�

			//int x[] = { 350, 400, 350, 400 };
			//int y[] = { 130, 130, 200, 200 };
			//g2.drawPolygon(x, y, 4);// ����Σ����ν��ĸ�������������

		}

	}

}